#!/usr/bin/python
"""

SYNOPSIS:
    runRLCS.py [OPTIONS]... TESTSDIR REFSDIR OUTSDIR LABELSDIR EXTN 

DESCRIPTION:
    This script will run RLCS for all the allaps and motifs of all
    the ragas. It requires four command line arguments.
    - First input is the path of the directory where the alaaps for
    different ragas are stored.
    - Second input is the path of the directory where the motifs for
    different ragas are stored.
    - Third is the path of the directory where the results are to be 
    stored. If this directory is already there, it will be deleted and 
    the new one is created and if it is not there it will be created.
    stored.
    - Fourth is the name of the extension used for the alaaps and motif
    files. Extension should be every followed by .wav. 
    eg: XXXX.wav.cent.feat_mod3 then,
    extn should be 'cent.feat_mod3' OR '.cent.feat_mod3'

OPTIONS:
    -d [val], --debug [val]\n\
        val: It should contain the path of the label directory
        Runs program in debug mode and creates a directory named
'debug.log' in the OUTSDIR to store digonals information.
    -w [val], --window [val]
        val : val times the ref length
              0 means no windowing
        default val is 1.5 (i.e. windowing)
    -s [val], --shift [val extnRef extnTest]
        val: this is the directory paths where files containing the shift
             points are present'
        default val is '' (i.e. default shift of 1)
        This argument only makes sense when using windowing
    -v [val], --voiced [val]
       val: (default) 0 means no need to VAD
            1 means VAD on test data.
            2 means VAD on query data. When VAD is run on the query data,
              inside the output directory for that query there will be
              different folders for different VADs of that query. Vad wavs
              for each query will also be stored in stored in folder
              named VAD.
            3 means VAD on both test and query.
            extnRef: extension of the reference file.
            extnTest: extension of the test file.
NOTE:
    Do not forget to end all the paths of the directories with a '/'

EXAMPLES:
    ./runRLCS /home/username/testsDir/ /home/username/refsDir/ /home/username/results/  cent.feat_mod
    ./runRLCS -w 1.5 -s /home/username/shiftDir /home/username/testsDir/ /home/username/refsDir/ /home/username/results/  cent.feat_mod
    ./runRLCS -d /home/username/labelDir/ -w 0 /home/username/testsDir/ /home/username/refsDir/ /home/username/results/ cent.feat_mod
    ./runRLCS --window 0 -d /home/username/labelDir/ /home/username/testsDir/ /home/username/refsDir/ /home/username/results/ cent.feat_mod    
    ./runRLCS --debug /home/username/labelDir/ /home/username/testsDir/ /home/username/refsDir/ /home/username/results/ cent.feat_mod


"""

MANUAL = "SYNOPSIS:\n\
    runRLCS.py [OPTIONS]... TESTSDIR REFSDIR OUTSDIR LABELSDIR EXTN\n\
\n\
DESCRIPTION:\n\
    This script will run RLCS for all the allaps and motifs of all \
    the ragas. It requires four command line arguments.\n\
    - First input is the path of the directory where the alaaps for \
different ragas are stored.\n\
    - Second input is the path of the directory where the motifs for \
different ragas are stored.\n\
    - Third is the path of the directory where the results are to be \
stored. If this directory is already there, it will be deleted and \
the new one is created and if it is not there it will be created.\n\
stored.\n\
    - Fourth is the name of the extension used for the alaaps and motif \
files. Extension should be every followed by .wav \
eg: XXXX.wav.cent.feat_mod3 then, \
extn should be 'cent.feat_mod3' OR '.cent.feat_mod3'\n\
\
\n\
OPTIONS:\n\
    -d [val], --debug [val]\n\
        val: It should contain the path of the label directory\n\
        Runs program in debug mode and creates a directory named \
'debug.log' in the OUTSDIR to store digonals information.\n\
    -w [val], --window [val]\n\
        val: val times the ref length\n\
              0 means no windowing\n\
        default val is 1.5 (i.e. windowing)\n\
    -s [val], --shift [val]\n\
        val: this is the directory paths where files containing the shift\
points are present'\n\
        default val is '' (i.e. default shift of 1)\
        This argument only makes sense when using windowing\n\
    -v [val], --voiced [val extnRef extnTest]\n\
       val: (default) 0 means no need to VAD\n\
            1 means VAD on test data.\n\
            2 means VAD on query data. When VAD is run on the query data, \
inside the output directory for that query there will be \
different folders for different VADs of that query. Vad wavs \
for each query will also be stored in stored in folder \
named VAD.\n\
            3 means VAD on both test and query.\n\
       extnRef: extension of the reference file.\n\
       extnTest: extension of the test file.\
\
\n\
NOTE:\n\
    Do not forget to end all the paths of the directories with a '/'\n\
\n\
EXAMPLES:\n\
    ./runRLCS /home/username/testsDir/ /home/username/refsDir/ /home/username/results/  feat_mod\n\
    ./runRLCS -w 1.5 -s /home/username/shiftDir /home/username/testsDir/ /home/username/refsDir/ /home/username/results/  feat_mod\n\
    ./runRLCS -d /home/username/labelDir/ -w 0 /home/username/testsDir/ /home/username/refsDir/ /home/username/results/ feat_mod\n\
    ./runRLCS --window 0 -d /home/username/labelDir/ /home/username/testsDir/ /home/username/refsDir/ /home/username/results/ feat_mod\n\
    ./runRLCS --debug /home/username/labelDir/ /home/username/testsDir/ /home/username/refsDir/ /home/username/results/ feat_mod\n"



import sys
import motif_source as ms

if len(sys.argv[1:]) < 4:
    exit('NOT ENOUGH ARGUMENTS:\n\n' + MANUAL)

# default window is 1.5
# default mode is normal hence default labelsDir is EMPTY
window = 1.5
mode = '--normal'
labelsDir = ''
shiftDir = ''
voiced = 0
voicedInfoRefExtn = ''
voicedInfoTestExtn = ''
algo = 'rlcs' #'rlcsmod'


# parsing the input options
i = 1
while sys.argv[i][0] == '-':
    
    if sys.argv[i] in ['-d', '--debug']:
        mode = '--debug'
        labelsDir = sys.argv[i+1]
        i += 2
                
    elif sys.argv[i] in ['-w', '--window']:
        window = float(sys.argv[i+1])
        i += 2
        
    elif sys.argv[i] in ['-s', '--shift']:
        shiftDir = sys.argv[i+1]
        i += 2
    
    elif sys.argv[i] in ['-v', '--voiced']:
        voiced  = int(sys.argv[i+1])
        [voicedInfoRefExtn, voicedInfoTestExtn] = [x for x in sys.argv[i+2:i+3 + 1]]
        i += 4

    elif sys.argv[i] in ['-a', '-algo']:
        algo = sys.argv[i+1]
        i += 2

    else:
        exit('ERROR IN OPTIONS TO THIS COMMAND:\n\n' + MANUAL)

if len(sys.argv[i:]) != 4:
    exit('NOT ENOUGH ARGUMENTS:\n\n' + MANUAL)

[testsDir, refsDir, outsDir, extn] = sys.argv[i:]
if extn[0] != '.': extn = '.' + extn




# for straight-linear window
##Td = 0 #0.45 #0.5 # 0
##rho =  0.9 #0.8
##beta = 0.5
##extrTd = 300 #500 # 75
##alpha = 0
##seqFilterTd = 0.45  # 0.8

# for cubic window and 1st pass
##Td = 0.45 #0.45 #0.5 # 0
##rho =  0.8 #0.8
##beta = 0.5
##extrTd = 300 #500 # 75
##alpha = 0
##seqFilterTd = 0.45  # 0.8

# for 2nd pass
#Td = 0.45 #0.45 #0.5 # 0
#rho =  0 #0.8
#beta = 0.5
#extrTd = 150 #500 # 75
#alpha = 0
#seqFilterTd = 0  # 0.45


Td = 0.45 #0.13 #0.30 #0.45 #0.5 # 0
rho =  0.8 #0.6 #0.8 #0.7 # (near to 1/4 th)
beta = 0.5
extrTd = 300 #500 # 75
alpha = 0
seqFilterTd = 0.0 #0.5  #0.45 #0.30


#for centFCC
#Td = 0.45 #0.13 #0.30 #0.45 #0.5 # 0
#rho =  0.8 #0.6 #0.8 #0.7 # (near to 1/4 th)
#beta = 0.5
#extrTd = '' #500 # 75
#alpha = 0
#seqFilterTd = 0.0 #0.5  #0.45 #0.30




print('Td = ' + str(Td))
print('rho = '+ str(rho)) #0.8 #0.8
print('beta = ' + str(beta))#0.5
print('extrTd = ' + str(extrTd)) #500 # 75
print('alpha = ' + str(alpha))#0
print('seqFilterTd = ' +str(seqFilterTd))#0.45  # 0.8


# TODO: write the debug code to write all the diags and all the
# motif_window information in a directory structure same as outsDir
# debugname = '/home/shrey/Projects/motif_match/Results/debug_ext'
# motif_windows = find_motif_windows(diags, gt_samples)

ms.RLCS_many_ragas(testsDir, refsDir, outsDir, labelsDir, extn, Td, \
                   rho, beta, extrTd, alpha, seqFilterTd, mode, window,
                   shiftDir, voiced, voicedInfoRefExtn, voicedInfoTestExtn, algo)

    
