
function[] =prepareOutputTonic()
    %getting tonic values
    tonicValues = load('GDTonicValues.mat');
    tonicValues = tonicValues.GDTonicValues;
    
    %getting songNames
    songNames = cell(length(tonicValues),1);
        fid = fopen('songNames.txt');
        count = 1;
        tline = fgetl(fid);
        while ischar(tline)
            songNames{count,1} = tline;
            tline = fgetl(fid);
            count = count + 1;
        end
         fclose(fid);
    

    dir = './Output_Tonic/';
    for i = 1:length(tonicValues)
        fileName = songNames{i};
        tonic = tonicValues(i);
        file = strcat(dir,fileName,'.txt');
        fid = fopen(file,'wt');
        fprintf(fid,'%s\n%s%s','#!/bin/bash','TONIC=',num2str(tonic));
        fclose(fid);    
    
    end
end
