
data = load('histValuesWithNorm.mat');
data = data.histValuesWithNorm;
[rows,cols]=size(data);

% getting similarites 
similarityScores = zeros(rows,rows);

for i = 1:rows
    for j = 1:rows
        similarityScores(i,j) = pdist2(data(i,:),data(j,:));
    end
end

%Now sort the rows based on highest scores and give best suggestions
numOfSuggestions = 5;
suggestionMatrix = zeros(rows,numOfSuggestions);

for i = 1 : rows
    temp = similarityScores(i,:);
    [sortedMatrix,indices]=sort(temp,'ascend');
    indices = indices(1,2:(numOfSuggestions+1)); %starting from 2 because 1st least score will be itself.
    suggestionMatrix(i,:) = indices;
end


%read the songNames.txt file
fid = fopen('songNames.txt');
tline = fgetl(fid);
songNames = cell(rows,1);
count = 1;
while ischar(tline)
    songNames{count,1} = tline;
    count = count + 1;
    tline = fgetl(fid);
end
fclose(fid);  %we have all song names in songNames variable

%convert the suggestion matrix into json format for website
fid = fopen('recommandationsEuclidean.txt','wt');
for i = 1:rows
    if(i~=rows)
    fprintf(fid,'\"%s\" : [\"%s\",\"%s\",\"%s\"], \n',upper(songNames{i,1}),upper(songNames{suggestionMatrix(i,1),1}),upper(songNames{suggestionMatrix(i,2),1}),upper(songNames{suggestionMatrix(i,3),1}));
    else 
    fprintf(fid,'\"%s\" : [\"%s\",\"%s\",\"%s\"]',upper(songNames{i,1}),upper(songNames{suggestionMatrix(i,1),1}),upper(songNames{suggestionMatrix(i,2),1}),upper(songNames{suggestionMatrix(i,3),1}));
   end
end
