%read all the pitch values of each song and tonic values, now do the tonic
%normalisation
clear
files = dir('./Output_Pitch/*.pitch');
numFiles = length(files(not([files.isdir])));
songNames = cell(1,numFiles);
count = 1;
for file = files'
    freq = load(strcat('./Output_Pitch/',file.name));
    %find the location where first non zero value(frequency) starts.
    time = freq(:,1);
    x = length(freq);
    freq = freq(:,2);
    freq = freq(freq<600);
    loc_nonzero = find(freq); %I am not removing in between zeros and tonic values, those will be not considered in pitch histogram
    %find first and last occurance of non zero values, remove starting and
    %ending zeros
    first_occur = loc_nonzero(1,1);
    last_occur = loc_nonzero(length(loc_nonzero),1);
    time = time(first_occur:last_occur,1);
    freq = freq(first_occur:last_occur,1);
      
    %This below code is for getting tonic.    
    temp = strrep(file.name,'.pitch',''); songName = temp;
    temp = strcat(temp,'.txt');  %get file at Output_Tonic having some text and required freq,get that frequency.
    tonic = fileread(strcat('./Output_Tonic/',temp));
    len = length(tonic);
    tonic = tonic(1,19:len); %to get the freq value
    tonic = str2num(tonic); %get tonic as a number
    songNames{1,count} =  songName;
    count = count + 1;
    
    
    %normalise the frequncies with tonic value with cent frequencies
    freq = freq(freq~=0);
    centFreq  = log2(freq/tonic);
    
    %need to delete all the -Inf values, which means 0 freq 
    idx = find(centFreq==-Inf);
    temp = 0;
    for i = 1:length(idx)
       disp('check');
       % centFreq(idx(i)-temp) = [];
       centFreq(idx(i))=0;
        temp  = temp + 1;
    end
    
    centFreq = 1200 * centFreq; 
   
    
    %for i=1:length(time)
     %  finalCentFreq(i,1) = time(i,1);
     %  finalCentFreq(i,2) = centFreq(i,1);
    
  % end
    
    
    save(strcat('./Normalised_Tonic/',songName,'.txt'),'centFreq','-ASCII'); %store in ascii format
    
    
end
%save song names list
fid = fopen('songNames.txt','wt');
fprintf(fid,'%s\n',songNames{:});
fclose(fid);


