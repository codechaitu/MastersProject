function[]=runMe()
    % step-1, get song tonic values using template matching
    getSongTonic();
    disp('Got song tonic');
    % step-2, prepare the tonic file for all songs
    prepareOutputTonic();
        disp('Prepared tonic files');
    % step-3, tonic normalisation of pitch
    tonicNormalisation();
        disp('Tonic Normalisation');
    % step-4, get the histograms
    clear;
    getHistograms();
    disp('Get Histograms');
    
    % step-5, find the euclidean distance between songs and get the json file
    findSimilaritiesUsingEuclideanDistance();
    disp('Found similarities');
    % step-6, plot recommendations using bar plot , this uses step-5 variables.
    plotBars();
    disp('Bars are plotted');



end
