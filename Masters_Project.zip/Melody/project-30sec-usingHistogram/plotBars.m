numOfSuggestions = 3;

data = load('histValuesWithNorm.mat');
data = data.histValuesWithNorm;
[r,c] = size(data);

for i =1 :r
    f=figure;
    subplot(4,1,1);
  
%    freq = load(strcat('Normalised_Tonic/',songNames{i},'.txt'));
       h = bar(data(i,:));
       ylabel('Count');xlabel('Bin Numbers');title(strcat(songNames{i},'-Reference Song'));
        for k = 1:numOfSuggestions
        songName = songNames{suggestionMatrix(i,k)};
        subplot(4,1,k+1)
         
         %freq1 = load(strcat('Normalised_Tonic/',songName,'.txt'));
        temp = bar(data(k,:));
         ylabel('Count');xlabel('Bin Numbers');title(strcat(songName,'-Suggested Song ',num2str(k)));
    end
   saveas(gcf,strcat('HeightNormalisedBars/',songNames{i},'.png'));
    
end
