% read all the pitch values

files = dir(strcat('Output_Pitch/','*.pitch'));

% writing all tonics to files
count = 1;
fid = fopen('TonicValues.txt','wt');
for file = files'
     freq = (strcat('Output_Pitch/',file.name));
     temp = file.name;temp = strrep(temp,'.pitch','');songName = temp;
     tonic = getTonicGD(freq, 'metadata', 1, 'hopSize' , 0.02);
     GDTonicValues(count) = tonic;
     count = count + 1;
     fprintf(fid,'%-30s %s Hz\n',songName,num2str(tonic));
     
end
save('GDTonicValues.mat','GDTonicValues');
fclose(fid);
