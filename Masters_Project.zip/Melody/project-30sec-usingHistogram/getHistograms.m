%plot the histograms
% 
% 1)fix num of bins and bin size
close all;
clear;
%binWidth = 20;
%nBins = 300;
binEdges = [-605:10:2405];  % for 2 and 1/2 octaves ,0:1200 is one octave
%getting all tonic normalised files 
normalisedTonicDir = './Normalised_Tonic/';
histogramDir = './Histograms/';
files = dir(strcat(normalisedTonicDir,'*.txt'));
numFiles = length(files(not([files.isdir])));
histogramSongNames = cell(1,numFiles);
histValuesWithoutNorm  = zeros(numFiles,length(binEdges)-1);

count = 1;
for file = files'
     freq = load(strcat(normalisedTonicDir,file.name));
     temp = file.name;temp = strrep(temp,'.txt','');songName = temp;
     histogramSongNames{1,count} =  songName;
     freq = freq(freq~=0);  
     % freq = rem(freq,1200); % folding back to 1200 hz freq's, here there is no need of folding
     %f=figure();
     h = histogram(freq,'BinEdges',binEdges);
     xlabel('Cent Frequency');
     ylabel('Number of Occurances');
     %h.NumBins = nBins;
     temp =strrep(file.name,'.txt',''); 
     title(temp);
     set(gca, 'XTick', [-700,0,700,1200,1900]);
     set(gca, 'XTickLabel', {'P_0','S','P','S_2','P_2'});
         
     saveas(gcf,strcat(histogramDir,temp,'-histogram.png'));
     
     histValuesWithoutNorm(count,:)=h.Values;
     count = count + 1;
end
%save song names list
fid = fopen('histogramSongNames.txt','wt');
fprintf(fid,'%s\n',histogramSongNames{:});
fclose(fid);

%without height normalising 
save('histValuesWithoutNorm.mat','histValuesWithoutNorm');
%height normalising the matrix
histValuesWithNorm = bsxfun(@times,histValuesWithoutNorm,1./sum(histValuesWithoutNorm,2));
save('histValuesWithNorm.mat','histValuesWithNorm');



