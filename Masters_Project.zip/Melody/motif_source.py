# Imports
from numpy  import argmin
import numpy as np
import scipy.io.wavfile as sciwav
import sys
import os
import math
#import matplotlib.pyplot as plt
import Image
import copy

from progressbar import *
from multiprocessing import *
import itertools as itl


# Path of the reference and Text
# These are the default paths change them if necessary
reference_path = '~/Projects/motif_match/Data/Reference/'
test_path = '~/Projects/motif_match/Data/Test/'

# Names of the ragas
# TODO: this needs to be changed
ragas = [ 'Bhairavi',
          'Kalyani',
          'Kamboji',
          'Kharaharapriya',
          'Shankarabharanam',
          'Varali'
          ]

#######################################
############ Functions ################
#######################################


# Messed up and not so important, it needs to be improved
def make_path(raga, data_type):
    '''(string, string) -> string

    Make a path to the raga file which can be of two data_type: 'ref'
    and 'test'

    >>> make_path('Bhairavi', 'ref')
    ~/Projects/motif_match/Data/Reference/Bhairavi_firsts/
    >>> make_path('Varali', 'test')
    ~/Projects/motif_match/Data/Test/Varali_fullwav/
    >>> make_path('Varali', 'Mason')
    data_type can be either 'ref' or 'test'
    '''
    
    if data_type == 'ref':
        return reference_path + raga + '_firsts/'
    elif data_type == 'test':
        return test_path + raga + '_fullwav'
    else:
        sys.exit("data_type can be either 'ref' or 'test'")


def union(a, b):
    '''(list, list) -> list

    return the union of two lists

    >>> union([1,2,3],[3,4,1])
    [1,2,3,4]
    >>> union([[1,2], [2,1], [2,3]], [[2,1], [2,5], [2,3]])
    [[1,2], [2,1], [2,3], [2,5]]
    '''
    c = [x for x in a]
    for x in b:
        if not x in c:
            c.append(x);
    return c

def dist(x, y, epsilon):
    '''(number, number, number) -> boolean

    Return True if x and y are epsilon away from each other otherwise False.
    It also returns distance
    
    >>> dist(144, 142, 3)
    [True, 2]
    >>> dist(99.5,100, 0.3)
    [False, 0.5]
    '''
    
    return [abs(x-y) <= epsilon, abs(x-y)]
    
# TODO: Make it work for backtrackAll. Currently backtrackAll is
# crashing (Explain below)
def LCSS(ref, test, epsilon = 1e-50 , weighted_score = False):
    '''(list of numbers, list of numbers, number, number, boolean) ->  list of tuples

    Find the Longest Common Sub-Sequence between the ref and test
    with epsilon (non-zero with default lim -> 0) as allowable error
    bound. If the weighted_score is True, the score of LCSS is
    increased by weighted score between 0 and 1 (i.e. higher the match
    more the score). Functions returns the list of subsequences.
    Each subsequence is a tuple of three lists: first one is LCSS,
    second is the list of indexes of the ref that correspond to the
    LCSS, third one is the list of indexes of the test that
    correspond to the LCSS.
    
    >>> LCSS([4,1,2,3],[2,4,3,5])
    [([4, 3], [0, 3], [1, 2])]
    >>> LCSS([21,22,15,16], [1, 21, 15, 5, 16])
    [([21, 15, 16], [0, 2, 3], [1, 2, 4])]
    '''
    
    # Divide by zero could cause problem
    if not epsilon:
        epsilon = 0.0000000000000000000000000000000000000001
        
    table =  LCSS_table(ref, test, epsilon, weighted_score)
    
    #unformated_matches = backtrackAll(table, ref, test, len(ref), len(test),epsilon, delta)
    um = backtrack(table, ref, test, len(ref), len(test),epsilon)
    
    return [(
            [m[0] for m in um],
            [m[1][0] for m in um],
            [m[1][1] for m in um]
           )]
      
            
def LCSS_table(ref, test, epsilon, weighted_score):
    '''(list, list) = list of list

    Fills out the DP table for LCSS with epsilon as a matching threshold.
    This is a helper function for LCSS
    '''
    table = [[0 for x in range(len(test)+1)] for x in range(len(ref)+1)]
    for i in range(1,len(ref)+1):
        for j in range(1,len(test)+1):
            if dist(ref[i-1], test[j-1], epsilon)[0]:
                table[i][j] = table[i-1][j-1] +\
                              (1 - weighted_score *\
                              (abs(ref[i-1]-test[j-1])/epsilon))
            else:
                table[i][j] = max(table[i][j-1], table[i-1][j])
    return table

# This function crashes due to recursion. Tail recusion doesn't help
# logically it should but I am not sure how python sees tail-recursion
# It needs to be improved maybe we should use our own stack for
# recursion
def backtrackAll(table, ref, test, i, j, epsilon, delta):
    '''(list of list, list, list, int, int) -> 
    Backtrack LCSS table to find all the longest common subsequences.
    Also find matched indexes for localizations.
    backtrackAll will return a list whose elements are longest common
    subsequences. Each sequence is inturn a list of matched points and
    their index w.r.t. ref and test.
    This is a helper function for LCSS
    '''

    if i==0 or j==0:
        return [[]]
    elif dist(ref[i-1], test[j-1], epsilon)[0]:
        return [X + [(ref[i-1],[i-1,j-1])] for X in\
                backtrackAll(table, ref, test, i-1, j-1,
                             epsilon)]
    else:
        R = []
        if table[i][j-1] >= table[i-1][j]:
            R = backtrackAll(table, ref, test, i, j-1,
                             epsilon)
        if table[i-1][j] >= table[i][j-1]:
            R = union(R, backtrackAll(table, ref, test, i-1, j,
                                      epsilon))
        return R


# This function crashes due to recursion. Tail recusion doesn't help
# logically it should but I am not sure how python sees tail-recursion
# It improved version which does not use recursion is backtrack()
def backtrackR(table, ref, test, i, j, epsilon):
    '''(list of list, list, list, int, int) -> list of tuple
    BacktrackR LCSS table to find a longest common subsequence.
    Also find matched indexes for localization.
    backtrack will return a list whose elements are tuple of
    matched points and list[their index w.r.t. ref and test].
    This is a helper function for LCSS (It uses recursion)
    '''
    if i==0 or j==0:
        return []
    elif dist(ref[i-1], test[j-1], epsilon)[0]:
        return backtrackR(table, ref, test, i-1, j-1,
                             epsilon) + [(ref[i-1],[i-1,j-1])]
    else:
        if table[i][j-1] > table[i-1][j]:
            return backtrackR(table, ref, test, i, j-1,
                             epsilon)
        else:
            return backtrackR(table, ref, test, i-1, j,
                                      epsilon)


def backtrack(table, ref, test, i, j, epsilon):
    '''(list of list, list, list, int, int) -> list of tuple
    BacktrackR LCSS table to find a longest common subsequence.
    Also find matched indexes for localization.
    backtrack will return a list whose elements are tuple of
    matched points and list[their index w.r.t. ref and test].
    This is a helper function for LCSS (It doesn't use recursion)
    '''
    seq = []
    while i != 0 and j != 0:
        if dist(ref[i-1], test[j-1], epsilon)[0]:
            seq.append((ref[i-1],[i-1,j-1]))
            i,j = i-1,j-1
        else:
            if table[i][j-1] > table[i-1][j]:
                i,j = i, j-1
            else:
                i,j = i-1, j

    seq.reverse()
    return seq

        
def run_LCSS(refdir, testdir, outdir):
    '''(dir,dir) -> dir

    For each ref in refdir find the LCSS with each of test in testdir
    and store the output in the outdir. Do not forget to include '/'
    at end of the dir names.
    '''

    refs = [ref for ref in os.listdir(refdir) if ref.endswith('.seq')]
    tests = [test for test in os.listdir(testdir) if test.endswith('.seq')]

    if not os.path.exists(outdir):
        os.makedirs(outdir)
    else:
        print("Deleting already existing outdir...\n")
        os.system("rm -R " + outdir)
        print("New one created")
        os.makedirs(outdir)

    for ref in refs:
        os.makedirs(outdir + ref) # making ref directory
        with open(refdir + ref) as f:
            ref_seq = [int(x) for x in f.read().split()]
        for test in tests:
            os.makedirs(outdir + ref + '/' + test)# making test directory
            with open(testdir + test) as f:
                test_seq = [int(x) for x in f.read().split()]
            print(ref, test)
            S = LCSS(ref_seq, test_seq)
            write_results_to_file(S, outdir + ref + '/' + test + '/' +
                                  str(1), refdir, testdir, ref, test)


def write_results_to_file(result, outdirname, refdir,
                          testdir, refname, testname):
    '''(List of Tuples, string) -> void

    This function will create a directory dirname and inside that dir
    it will create two text file for ref and test. Files will have the
    sequences, from the matched subsequence in the result, w.r.t. the
    test query i.e. matched elements which are adjaecnt. The format is
    similar to the "feat" file.

    '''
    with open(refdir + refname[:-4] + '.feat') as f:
        ref_seq_feat = f.readlines()
    with open(testdir + testname[:-4] + '.feat') as f:
        test_seq_feat = f.readlines()
    os.makedirs(outdirname)
    with open(outdirname + '/ref.match', 'w') as rm,\
         open(outdirname + '/test.match', 'w') as tm:
             for s in result:
                 i,j = 1,1
                 while i < len(s[0]):
                   flag_write = False
                   while (j < len(s[0]) and s[2][j]-s[2][j-1] == 1):
                      flag_write = True
                      rm.write(ref_seq_feat[s[1][j-1]])
                      tm.write(test_seq_feat[s[2][j-1]])
                      j = j+1
                   if (flag_write):
                      rm.write(ref_seq_feat[s[1][j-1]] + '\n')
                      tm.write(test_seq_feat[s[2][j-1]] + '\n')
                   i = max([j,i+1])
                   j = i

# description section needs to be edited to consider some of the
# of the arguments.
def RLCS_mod(testVal0, refVal0, Td = 1e-50, rho = 0.5, beta = 0.5, extrTd = 150, alpha = 0.3, N=0, toggle = False):
    '''(list of tuple, list of tuple) -> list of list

    This function will give Rough Longest Common Subsequence which is
    a variant of Longest Common Subsequence. This is the
    implementation of algorithm given in the HWEI-JEN LIN paper:
    "Music Matching Based on Rough Longest Common Subsequence".

    testVal0 & refVal0 are list of tuples where the first entry is the
    sequence nomber and the second entry is the exterme point value.
    Td is matching threshold; 0 (default) means exact match.
    rho (range = (0,1))is RLCS matched rate i.e. min threshold on
    len(RLCS).
    beta (range = (0,1)) is the weighting parameter  used while
    calculating score; (beta) weighs WAT and (1-beta) weighs WAR.
    extrTD is the exteme point threshold;
    alpha is weighting factor of primitive sequence match and (1-alpha)
    is that of extreme points match.

    flag: True means considering extreme points
        : False means without extreme points

    It will return cost, direction, WAR, WAT, score tables.

    >>> t = [1,2,3,4,5,6,1,2,3,8,9]
    >>> r = [1,2,3,4]
    >>> a = [0 for x in range(len(t))]
    >>> [c,d,wr,wt,s] = RLCS(zip(t,a), zip(r,a), 0, 0.8, 0.5, 0, 1)
    '''
     
   
    if not Td: Td = 1e-50
    if not extrTd: extrTd = 1e-50
    #print extrTd

    EXTRTD = extrTd # extreme point threshold
    ALPHA = alpha # weighing coieficient for sequences
    
    # for the consistancy in the for loop below 
    [testVal, refVal]  = [[[0]] + testVal0, [[0]] + refVal0]
    
    m = len(testVal);
    n = len(refVal);
    
    assert m>2 and  n>2,  'length of ref anf test should be > 2' 

    if N == 0:
      if toggle: N = m
      else: N = n

    cost      = [[0 for x in range(n)] for x in range(m)];
    direction = [[0 for x in range(n)] for x in range(m)];
    WAR       = [[0 for x in range(n)] for x in range(m)];
    WAT       = [[0 for x in range(n)] for x in range(m)];
    score     = [[0 for x in range(n)] for x in range(m)];
    costD    = [[0 for x in range(n)] for x in range(m)];
#    print ('Inside RLCS')
    for i in range(1, m):
        for j  in range(1,n):
            if distRLCS(testVal[i], refVal[j], EXTRTD, ALPHA) < Td:

                direction[i][j] = "\\" # '\' for cross

                # if the previous diagonal was an up then start a new sub-sequence
                # i.e. cost matrix should be restarted instead of adding to the
                # privious diagonal entry.
##                #if (direction[i-1][j-1] == '|'):
##                if WAT[i-1][j-1] > len(ref)*1.5 
##                    cost[i][j] = (1 - distRLCS(test[i],ref[j],EXTRTD,ALPHA,FLAG)/Td);
##                    WAT[i][j] = 1;
##                    WAR[i][j] = 1;
##                else:
                cost[i][j] = cost[i-1][j-1] + \
                                (1 - distRLCS(testVal[i],refVal[j],EXTRTD,ALPHA)/Td)

		WAT[i][j] = WAT[i-1][j-1] + \
                                (1 - distRLCS(testVal[i],refVal[j],EXTRTD,ALPHA)/Td)

		WAR[i][j] = WAR[i-1][j-1] + \
                                (1 - distRLCS(testVal[i],refVal[j],EXTRTD,ALPHA)/Td)

                costD[i][j] = costD[i-1][j-1] + 1      
#.                WAT[i][j] = WAT[i-1][j-1] + 1
#.                WAR[i][j] = WAR[i-1][j-1] + 1
                    
                # TODO
                # if wat[up] > wat[left] and wat[up] >= len ref.
                # if wat[left] < 
            elif cost[i-1][j] > cost[i][j-1]:
                # If the wat[up] > len(ref) then
                # force it to be like cost[i-1][j] = cost[i][j-1]
##                if WAT[i-1][j] >= len(ref)-1:
##                    cost[i][j] = cost[i][j-1]
##                    direction[i][j] = '-' # '-' for left
##                    WAT[i][j] = WAT[i][j-1]
##                    if WAR[i][j-1] > 0:
##                        WAR[i][j] = WAR[i][j-1] + 1
##                    else:
##                        WAR[i][j] = 0
##                # otherwise do what is supposed to be done.
##                else:
                    cost[i][j] = cost[i-1][j]
                    direction[i][j] = '|' # '|' for up
                    WAR[i][j] = WAR[i-1][j]
                    if WAT[i-1][j] > 0:
                        WAT[i][j] = WAT[i-1][j] + 1
                    else:
                        WAT[i][j] = 0
                    costD[i][j] = costD[i-1][j]
            else:
                cost[i][j] = cost[i][j-1]
                direction[i][j] = '-' # '-' for left
                WAT[i][j] = WAT[i][j-1]
                if WAR[i][j-1] > 0:
                    WAR[i][j] = WAR[i][j-1] + 1
                else:
                    WAR[i][j] = 0
                costD[i][j] = costD[i][j-1]
            # modified N check for toggle        
            #print N-1
            ################################
#            if cost[i][j] > 60:
#              print(cost[i][j], rho,(N-1), WAT[i][j], WAR[i][j], toggle, n,m)
            
#              score[i][j] = (beta*cost[i][j]**2)/((N-1)*WAT[i][j]) + \
#                              ((1-beta)*cost[i][j]**2)/((N-1)*WAR[i][j])

#              print(beta,(beta*cost[i][j]**2),((N-1)*WAT[i][j]),((1-beta)*cost[i][j]**2),((N-1)*WAR[i][j]), score[i][j])

#              a = input('pausing...')
            ################################


            if WAT[i][j] > 0 and WAR[i][j] > 0:

           # if cost[i][j] >= rho*(N-1) and WAT[i][j] != 0  and WAR[i][j] != 0:
#.              score[i][j] = ((beta * cost[i][j]/WAT[i][j] + (1-beta) * cost[i][j]/WAR[i][j])) * (cost[i][j]/(N-1))
 
#            if costD[i][j] >= rho*(N-1) and WAT[i][j] != 0 and WAR[i][j] != 0:
                ###NN = (N-1) - costD[i][j] + cost[i][j]
              score[i][j] = ((beta * cost[i][j]/WAT[i][j] + (1-beta) * cost[i][j]/WAR[i][j])) * ( (cost[i][j]+ cost[i][j]) / (costD[i][j] + N - 1))

            else:
              score[i][j] = 0

    #print (max([max(x) for x in costD]), max([max(x) for x in cost]), N-1)
    #print (max([max(x) for x in score]))


    return [cost, costD, direction, WAR, WAT, score]


# description section needs to be edited to consider some of the
# of the arguments.
def RLCS(testVal0, refVal0, Td = 1e-50, rho = 0.5, beta = 0.5, extrTd = 150, alpha = 0.3, N=0, toggle = False):
    '''(list of tuple, list of tuple) -> list of list

    This function will give Rough Longest Common Subsequence which is
    a variant of Longest Common Subsequence. This is the
    implementation of algorithm given in the HWEI-JEN LIN paper:
    "Music Matching Based on Rough Longest Common Subsequence".

    testVal0 & refVal0 are list of tuples where the first entry is the
    sequence nomber and the second entry is the exterme point value.
    Td is matching threshold; 0 (default) means exact match.
    rho (range = (0,1))is RLCS matched rate i.e. min threshold on
    len(RLCS).
    beta (range = (0,1)) is the weighting parameter  used while
    calculating score; (beta) weighs WAT and (1-beta) weighs WAR.
    extrTD is the exteme point threshold;
    alpha is weighting factor of primitive sequence match and (1-alpha)
    is that of extreme points match.

    flag: True means considering extreme points
        : False means without extreme points

    It will return cost, direction, WAR, WAT, score tables.

    >>> t = [1,2,3,4,5,6,1,2,3,8,9]
    >>> r = [1,2,3,4]
    >>> a = [0 for x in range(len(t))]
    >>> [c,d,wr,wt,s] = RLCS(zip(t,a), zip(r,a), 0, 0.8, 0.5, 0, 1)
    '''
     
   
    if not Td: Td = 1e-50
    if not extrTd: extrTd = 1e-50
    #print extrTd

    EXTRTD = extrTd # extreme point threshold
    ALPHA = alpha # weighing coieficient for sequences
    
    # for the consistancy in the for loop below 
    [testVal, refVal]  = [[[0]] + testVal0, [[0]] + refVal0]
    
    m = len(testVal);
    n = len(refVal);
    
    assert m>2 and  n>2,  'length of ref anf test should be > 2' 

    if N == 0:
      if toggle: N = m
      else: N = n

    cost      = [[0 for x in range(n)] for x in range(m)];
    direction = [[0 for x in range(n)] for x in range(m)];
    WAR       = [[0 for x in range(n)] for x in range(m)];
    WAT       = [[0 for x in range(n)] for x in range(m)];
    score     = [[0 for x in range(n)] for x in range(m)];
    costD    = [[0 for x in range(n)] for x in range(m)];
#    print ('Inside RLCS')
    for i in range(1, m):
        for j  in range(1,n):
            if distRLCS(testVal[i], refVal[j], EXTRTD, ALPHA) < Td:

                direction[i][j] = "\\" # '\' for cross

                # if the previous diagonal was an up then start a new sub-sequence
                # i.e. cost matrix should be restarted instead of adding to the
                # privious diagonal entry.
##                #if (direction[i-1][j-1] == '|'):
##                if WAT[i-1][j-1] > len(ref)*1.5 
##                    cost[i][j] = (1 - distRLCS(test[i],ref[j],EXTRTD,ALPHA,FLAG)/Td);
##                    WAT[i][j] = 1;
##                    WAR[i][j] = 1;
##                else:
                cost[i][j] = cost[i-1][j-1] + \
                                (1 - distRLCS(testVal[i],refVal[j],EXTRTD,ALPHA)/Td)

#.		WAT[i][j] = WAT[i-1][j-1] + \
#.                                (1 - distRLCS(testVal[i],refVal[j],EXTRTD,ALPHA)/Td)

#.		WAR[i][j] = WAR[i-1][j-1] + \
#.                                (1 - distRLCS(testVal[i],refVal[j],EXTRTD,ALPHA)/Td)

                costD[i][j] = costD[i-1][j-1] + 1      
                WAT[i][j] = WAT[i-1][j-1] + 1
                WAR[i][j] = WAR[i-1][j-1] + 1
                    
                # TODO
                # if wat[up] > wat[left] and wat[up] >= len ref.
                # if wat[left] < 
            elif cost[i-1][j] > cost[i][j-1]:
                # If the wat[up] > len(ref) then
                # force it to be like cost[i-1][j] = cost[i][j-1]
##                if WAT[i-1][j] >= len(ref)-1:
##                    cost[i][j] = cost[i][j-1]
##                    direction[i][j] = '-' # '-' for left
##                    WAT[i][j] = WAT[i][j-1]
##                    if WAR[i][j-1] > 0:
##                        WAR[i][j] = WAR[i][j-1] + 1
##                    else:
##                        WAR[i][j] = 0
##                # otherwise do what is supposed to be done.
##                else:
                    cost[i][j] = cost[i-1][j]
                    direction[i][j] = '|' # '|' for up
                    WAR[i][j] = WAR[i-1][j]
                    if WAT[i-1][j] > 0:
                        WAT[i][j] = WAT[i-1][j] + 1
                    else:
                        WAT[i][j] = 0
                    costD[i][j] = costD[i-1][j]
            else:
                cost[i][j] = cost[i][j-1]
                direction[i][j] = '-' # '-' for left
                WAT[i][j] = WAT[i][j-1]
                if WAR[i][j-1] > 0:
                    WAR[i][j] = WAR[i][j-1] + 1
                else:
                    WAR[i][j] = 0
                costD[i][j] = costD[i][j-1]
            # modified N check for toggle        
            #print N-1
            ################################
#            if cost[i][j] > 60:
#              print(cost[i][j], rho,(N-1), WAT[i][j], WAR[i][j], toggle, n,m)
            
#              score[i][j] = (beta*cost[i][j]**2)/((N-1)*WAT[i][j]) + \
#                              ((1-beta)*cost[i][j]**2)/((N-1)*WAR[i][j])

#              print(beta,(beta*cost[i][j]**2),((N-1)*WAT[i][j]),((1-beta)*cost[i][j]**2),((N-1)*WAR[i][j]), score[i][j])

#              a = input('pausing...')
            ################################


            if WAT[i][j] > 0 and WAR[i][j] > 0:

           # if cost[i][j] >= rho*(N-1) and WAT[i][j] != 0  and WAR[i][j] != 0:
              score[i][j] = ((beta * cost[i][j]/WAT[i][j] + (1-beta) * cost[i][j]/WAR[i][j])) * (cost[i][j]/(N-1))
 
#            if costD[i][j] >= rho*(N-1) and WAT[i][j] != 0 and WAR[i][j] != 0:
                ###NN = (N-1) - costD[i][j] + cost[i][j]
#.              score[i][j] = ((beta * cost[i][j]/WAT[i][j] + (1-beta) * cost[i][j]/WAR[i][j])) * ( (cost[i][j]+ cost[i][j]) / (costD[i][j] + N - 1))

            else:
              score[i][j] = 0

    #print (max([max(x) for x in costD]), max([max(x) for x in cost]), N-1)
    #print (max([max(x) for x in score]))


    return [cost, costD, direction, WAR, WAT, score]








# modified distance function for RLCS
def distRLCS(X, Y, extrTd, alpha):
    '''(tuple, tuple, number, number, boolean) -> boolean
    
    distRLCS is a 2d distance function.
    extrTd is extreme point threshold.
    alpha is a weighing coeificient.\
    flag: when True it will consider extreme point distance.
        : when False it will not consider extreme point distance.
    Returns the rough distance
    
    >>> distRLCS((5,144), (5,115), 300, 0.3)
    >>> 0.0
    '''
    
    d1 = not X[0] == Y[0]
   

    ###############################
    ##############################
 
    # extrTd should be greater than 200 (TTd: True Threshold).
    # if it is less than 200. consider extrTd as TTd.


    d2 = 0
#    print X
#    print Y

############################################
###########################################
    for z in zip(X[1],Y[1]):
        [x,y] = z
        if abs(x-y) <= extrTd:
              d2  +=  abs(x-y)**3/float(extrTd**3)
        else:
              d2  += 1
    d2 /= len(X[1])
##########################################
#########################################



#############################
### Cosine Distance. Only for 
### the positives and thus bounded in [0,1]
### negative nums in the spectogram 
### doesnot really matter.
############################
  
#    st = 8
#    ed = 18  
#    [X1,Y1] = [X[1], Y[1]]
#    numel = sum([X1[i]*Y1[i] for i in range(st,ed) if X1[i] > 0 and Y1[i] > 0])
#    sum1 = sum([X1[i]**2 for i in range(st,ed) if X1[i] > 0 ]) 
#    sum2 = sum([Y1[i]**2 for i in range(st,ed) if Y1[i] > 0 ])
#    denomel = math.sqrt(sum1) * math.sqrt(sum2)
    
#    if not denomel: d2 = 1.0
#    else: d2 = 1 - numel/denomel 

###    else: d2 = 1-(1-math.acos(numel/denomel)/math.pi)

#############################


    
##    TTd = 200
##    if abs(X[1]-Y[1]) <= TTd:
##        d2 = 0
##    elif abs(X[1]-Y[1]) <= extrTd:
##        d2 = (abs(X[1] - Y[1])-TTd)/(float(extrTd)-TTd)
##    else:
##        d2 = 1
    
    return alpha*d1 + (1-alpha)*d2


def filter2D(score_mat, score_threshold, cost_mat,costD_mat, WAT_mat, WAR_mat):
    '''(list of list, num, list of list, list of list, list of list) -> list of tuple

    This function filters the matrix by max-threshold. It returns a list
    tuple (x-index, y-index, value) which is sorted in a desceding order by
    the value as a key.
    The output of filter2D will give starts which is a list of tuples
    that contains:
    (test_index, ref_index, score_val, cost_val, len_test, len_ref, WAT_val, WAR_val)

    Each tuple represents the beginning of sequences.
    NOTE: this function is used to filter the score matrix.
    
    >>> SCR = [[x for x in range(1,6)] for y in range(1,6)]
    >>> COST = [[x for x in range(1,6)] for y in range(1,6)]
    >>> WAT = [[x for x in range(1,6)] for y in range(1,6)]
    >>> WAR = [[x for x in range(1,6)] for y in range(1,6)]
    >>> filter2D(SCR, 4, COST, WAT, WAR)
    [(0, 4, 5, 5, 4, 4, 5, 5), (1, 4, 5, 5, 4, 4, 5, 5), (2, 4, 5, 5, 4, 4, 5, 5), (3, 4, 5, 5, 4, 4, 5, 5), (4, 4, 5, 5, 4, 4, 5, 5), (0, 3, 4, 4, 4, 4, 4, 4), (1, 3, 4, 4, 4, 4, 4, 4), (2, 3, 4, 4, 4, 4, 4, 4), (3, 3, 4, 4, 4, 4, 4, 4), (4, 3, 4, 4, 4, 4, 4, 4)]
    '''

    # getting the enteries which are greter than or equal to threshold.
    result = [(test_index, ref_index, score_val,
               cost_mat[test_index][ref_index],costD_mat[test_index][ref_index], len(score_mat)-1, len(score_row)-1,
               WAT_mat[test_index][ref_index], WAR_mat[test_index][ref_index])
              for test_index, score_row in enumerate(score_mat)
              for ref_index, score_val in enumerate(score_row)
              if score_val >= score_threshold]

    # returning the list created above in decreasing order of value.
    return sorted(result, key=lambda val: val[2], reverse=True)


def get_unique_seqs(testVal, refVal, direction, starts, rho, n, cost_mat, st_test, st_ref, toggle):
    '''(list of num, list of lists, list of tuple, num, num, num, list_list  ) -> list of list

    The output of filter2D will give starts which is a list of tuples
    that contains indexes, score values, cost values, len_of_test, len_of_ref,
    wat and war. Each tuple represents the beginning of sequences.
    
    Then using testVal, direction matrix ,returned by RLCS, we find the RLCseqs
    and we make sure that sequences_w are unique.
    
    n is the length of the ref sequence.
    st is the start index of the window.
    
    It returns list of lists where each element is sequence represented
    as a tuple.
    '''
    
    dmap = {'\\':(1,1), '|':(1,0), '-':(0,1)}

    seen  = set() # To keep track of the notes already processed. It is 
                  # used to maintain uniqueness.
    xseen = set() # to disallow overlaps
    
    result = [[]]
    scores = []
    costs = []
    costDs = []
    lens_test = []
    lens_ref = []
    wats = []
    wars = []
    uniques_test = []
    uniques_ref = []
    
    i = 0 # iterator for different sequences_w
    #print(st)
    for x,y,score,cost,costD,len_test,len_ref,wat,war in starts:
        j=0
        while (x != 0 and y != 0 and cost_mat[x][y] != 0):
            # if already seen this point then break
            if (x,y) in seen:
                break
            # otherwise add this point as seen
            else:
                seen.add((x,y))

# this for the overlaps
            if x in xseen:
                break

            d = direction[x][y]
##
##            if d == '|':
##                break
##                
            #if d == '\\':
                #shifted by st which is the start index of the window
            if toggle:
                result[i].append((y - 1 + st_ref, x - 1 + st_test, refVal[y-1][0]))
            else:
                result[i].append((x - 1 + st_test, y - 1 + st_ref, testVal[x-1][0]))
            
            x -= dmap[d][0]
            y -= dmap[d][1]
                
#TODO: set the threshold such that it works.
#            elif direction[x][y] == '-':
#               [x, y] = [x,y-1]
##
##            elif x >= 2 and y >= 2 and direction[x-1][y-1] == '\\':
##                result[i].append((x-1, y-1, test[x-1][0]))
##                result[i].append((x-2, y-2, test[x-2][0]))
##                [x, y] = [x-2, y-2] 
####                


        #This might not work when we are allowing gaps in the test
        #if len(result[i]) > rho*n:

        # This works when gaps are allowed in the test
        # largest test index - smallest test index + 1 > rho*n
##        print(i)
##        print(len(result[i]))
##        print (result[i])
        lenr = len(result[i])
        
        #if(lenr>0):
         #   print(result[i][0][0] - result[i][lenr-1][0] + 1)
        if lenr > 0: #. and \
#.           result[i][0][0] - result[i][lenr-1][0] + 1 > rho*n:
            
            # comment these two lines when duplicate results are allowed
            for r in result[i]:
                if toggle:
                    xseen.add(r[1]+1-st_test) # set of x's
                else:
                    xseen.add(r[0]+1-st_test) # set of x's
            result[i] = result[i][::-1]#sorted(result[i], key=lambda scr: scr[1])
            scores.append(score)
            costs.append(cost)
            costDs.append(costD)
            if toggle:
                lens_test.append(len_ref)
                lens_ref.append(len_test)
                wats.append(war)
                wars.append(wat)
            else:
                lens_test.append(len_test)
                lens_ref.append(len_ref)
                wats.append(wat)
                wars.append(war)

            uniques_test.append(len(set(zip(*result[i])[0])))
            uniques_ref.append(len(set(zip(*result[i])[1])))

            i += 1
            result.append([])
            break  # remove for multiple results within a window 
        else:
            result[i] = []
            
    return [result[:-1], scores, costs, costDs, lens_test, lens_ref, wats, wars, uniques_test, uniques_ref]


# Need to be modified; not yet complete
# Not Using this
def show_diagonal(direction, sequences_w, st, toggle):
    '''(list of list, list of tuple) -> None
    This is  to show the diagonals as an image
    st is the start index of the window.
    '''

    #dmap = {0:(0,0,0), '\\':(255,255,255), '|':(0,0,0), '-':(0,0,0)}
    dmap = {0:0, '\\':150, '|':100, '-':50}
    dmat = [[dmap[x] for x in D] for D in direction]
    
    px, py = 0,0
    for seq in sequences_w:
        for s in seq:
            if toggle:
                dmat[s[1]+1][s[0]+1 - st] = 255
            else:
                dmat[s[0]+1 - st][s[1]+1] = 255
            
            if px == 0 and py == 0:
                px, py = s[0]+1 - st, s[1]+1
            else:
                if  s[1] + 1 - py > 1:
                    for y in range(py+1,s[1]+1):
                        if toggle:
                            dmat[y][px] = 255
                        else:
                            dmat[px][y] = 255
                        
                if  s[0]+1 - st - px  > 1:
                    for x in range(px, s[0]+1 - st+1):
##                        print x
##                        print s[0]+1 - st
##                        print(len(dmat))
##                        print(len(dmat[0]))
                        if toggle:
                            dmat[s[1]+1][x] = 255
                        else:
                            dmat[x][s[1]+1] = 255
                
                        
                px, py = s[0]+1 - st, s[1]+1
                
                
            
    
    #img = Image.fromarray(array(dmat, dtype = uint8), 'RGB')
    #img.show()
    return dmat


# This and the previous write_results_to_files function need to made
# as one function.
def write_to_file(sequences_group, testFile, refFile, outFile, gt_sample_indices, motifName, mode):
    ''' (list of tuple, list of list, string) -> None
    
    Writes sequences_group to outfile in the for of test file and
    returns the number of true_positives.
    
    '''
    
    
    # to count true-positives (only makes sense when debug mode is on)
    count_true = 0
    # how far to look ie (gt_sample_index + ?)
    # look_till = 5    
    # what percentage of match is okay to check for true positives
    match_per = 0.8
    
   
    with open(testFile) as f:
        #testData = [(x.split()[0], x.split()[1], x.split()[2]) for x in f.readlines()]
        testData = [x.split() for x in f.readlines()]
    with open(refFile) as f:
        #refData = [(x.split()[1], x.split()[2]) for x in f.readlines()]
        refData = [x.split()[1:] for x in f.readlines()]

    with open(outFile, 'a') as f:
        # for each sequence group
        g = 0
        for seq_grp in sequences_group:
            g += 1
            
            flag = False
            
            if mode == '--debug':
                for  seq_tuple in seq_grp:

                    seq = seq_tuple[0]
                    
                    # Search till this point for gt_sample_index
                    #search_till = int(len(seq)*3/4.0)

                    for gt_sample_index_start, gt_sample_index_end in gt_sample_indices:
                        #look = 0
                        #while look < look_till:
                         #   if gt_sample_index + look >= seq[0][0] and \
                         #      gt_sample_index + look <= seq[search_till][0]:
                                
                                
                          #      flag = True
                          #      break
                         #   look += 1
                            
                        #if flag:
                         #   break
                        if (seq[0][0] >= gt_sample_index_start and seq[int(match_per*len(seq))][0] <= gt_sample_index_end)\
                                                                or\
                           (seq[-1][0] <= gt_sample_index_end and seq[int((1-match_per)*len(seq))][0] >= gt_sample_index_start)\
                                                                or\
                           (seq[0][0] <= gt_sample_index_start and gt_sample_index_end-((1-match_per)*(gt_sample_index_end - gt_sample_index_start +1)) <= seq[-1][0])\
                                                                or\
                           (gt_sample_index_end  <=  seq[-1][0] and gt_sample_index_end-(match_per*(gt_sample_index_end - gt_sample_index_start +1)) >= seq[0][0]):
                            flag = True
                            break
                        
                            
                    if flag:
                        break

            # signifies the begining of the group
            f.write('*'*5+'Group-'+str(g)+'*'*5+'\n')          
            
            if mode == '--debug':
                # write true pos or false pos info
                # flag value can only change if the    
                if not flag:
                    f.write('False\n')
                else:
                    f.write('True\n')                  
                    os.makedirs(outFile[:outFile.rfind('/',0,
                                              outFile.rfind('/', 0,
                                                            outFile.rfind('/')
                                                            )
                                           )
                                  ] + '/debug.log' +
                                outFile[outFile.rfind('/',0,
                                              outFile.rfind('/', 0,
                                                            outFile.rfind('/')
                                                            )
                                           ):outFile.rfind('_result')
                                ] + '/' + 'Group_' + str(g)
                               )
            
            
            i = 1

            #print seq_grp
            # writing all sequences of this group in a file
            for seq, score, cost, costD, len_test, len_ref, wat, war, unique_test, unique_ref in seq_grp:

                # write
                # start_time end_time score cost len_test len_ref wat war
                f.write(str(float(testData[seq[0][0]][1])/100.0) + ' ' + 
                        str(float(testData[seq[-1][0]][1])/100.0) + ' ' +
                        str(score) + ' ' + str(cost) + ' ' + str(costD)+ ' ' + str(len_test) + ' ' +
                        str(len_ref) + ' ' + str(wat) + ' '+ str(war) + ' ' +
                        str(unique_test) + ' ' + str(unique_ref) + '\n')

                # write sequence as in the input
                for s in seq:
                    f.write(' '.join(testData[s[0]] + refData[s[1]]) + '\n')
                f.write('\n')

                # for debug mode (flag val can only change debug mode is on)
##                if flag:
##                    with open(outFile[:outFile.rfind('/', 0,
##                                              outFile.rfind('/', 0,
##                                                            outFile.rfind('/')
##                                                            )
##                                           )
##                                  ] + '/debug.log' +
##                                outFile[outFile.rfind('/',0,
##                                              outFile.rfind('/', 0,
##                                                            outFile.rfind('/')
##                                                            )
##                                           ):outFile.rfind('_result')
##                                ] + '/' + 'Group_' + str(g) +
##                               '/' + 'diag'+ '_'+ str(i) +
##                               '.debug','w') as f2:
##                        for a in diag[0]:
##                            for aa in a:
##                                f2.write(str(aa) + ' ')
##                            f2.write('\n')
                i = i + 1


    # TODO: after the sequence output is changed to give all the
    # sequences from start to end, please change this code to
    # search only in the first colums of sequences for gt_sample_index.

    # TODO: if this code is not going to change. i.e. if the user
    # always demands the labels (True or False) then merge the code
    # above and below.


    if mode == '--debug':    
        # Checking if all marked motif have been identified or not
        
        # to keep track of motif number
        motifNum = 1
        for gt_sample_index_start, gt_sample_index_end in gt_sample_indices:
            flag  = False
            g = 0
            for seq_grp in sequences_group:
                g += 1
                for  seq_tuple in seq_grp:

                    seq = seq_tuple[0]

                    # Search till this point for gt_sample_index
                    # search_till = int(len(seq)*3/4.0)
                    
                    # how far to look for
                    # look = 0
                    #while look < look_till:
                    if (seq[0][0] >= gt_sample_index_start and seq[int(match_per*len(seq))][0] <= gt_sample_index_end)\
                                                           or\
                       (seq[-1][0] <= gt_sample_index_end and seq[int((1-match_per)*len(seq))][0] >= gt_sample_index_start)\
                                                           or\
                       (seq[0][0] <= gt_sample_index_start and gt_sample_index_end-((1-match_per)*(gt_sample_index_end - gt_sample_index_start +1)) <= seq[-1][0])\
                                                            or\
                       (gt_sample_index_end  <=  seq[-1][0] and gt_sample_index_end-(match_per*(gt_sample_index_end - gt_sample_index_start +1)) >= seq[0][0]):

                        count_true += 1
                        #print('Motif ' +  motifName + ' number ' +
                        #      str(motifNum) + ' ' + ' (' +
                        #      str(gt_sample_index_start) + ', ' + str(gt_sample_index_end) + ') ' +
                        #      ' is present in group: ', g)
                        flag = True
                        break
                    
                if flag:
                    break
            
            motifNum += 1            
            # if fails to find gt_sample_index in sequences then
            # write about it in a log file.
            if not flag:
                print("\nError: Could not find motif " + motifName +
                      " number " + str(gt_sample_indices.index((gt_sample_index_start,gt_sample_index_end))+1)
                      + ' ('+str(gt_sample_index_start)+ ', ' + str(gt_sample_index_end)+')')
                print("Possible Solution: loosen your threshold")
                print("Writing about it in errors.log\n\n")
                with open(outFile[:outFile.rfind('/',0,
                                                  outFile.rfind('/', 0,
                                                                outFile.rfind('/')
                                                                )
                                               )
                                 ] + '/errors.log', 'a') as f2:
                    f2.write(' '.join([testFile, motifName,
                                      str(gt_sample_indices.index(
                                          (gt_sample_index_start, gt_sample_index_end)) + 1),'\n']
                                    )
                            )
                
    return count_true


def find_motif_windows(d_mats, indexes):
    """(list of tuples, list of num) -> dict{num:list}

    This function will look for windows which contain 'indexes' in
    them. d_mats is a list of tuple containing diagonal matrix of
    that window, start index of that window and its end index.

    It will return a dictionary whose keys are the indexes and values
    is a list containg the window numbers which contain those indexes.
    
    >>> dummy = [[xx for xx in range(5)] for x in range(5)]
    >>> d_mats = [(dummy,100,400), (dummy, 345, 500), (dummy, 678, 900)]
    >>> find_motif_windows(d_mats,[350,5000])
    {5000: [], 350: [0, 1]}
    >>> find_motif_windows(d_mats,[450,800])
    {800: [2], 450: [1]}
    """

    result = dict.fromkeys(indexes)
    
    # loop over indexes to look for each index in d_mats
    for index in indexes:
        window_number = 0
        result[index] = []
        for d,st,ed in d_mats:
            if index >= st and index <= ed:
                result[index].append(window_number)
            window_number += 1
        
    return result            

def sequences_compare(A,B):
    ################
    #print A
    #print B
    #a = input('pausing')
    ################
    if A[0][0] == B[0][0] and A[0][-1] == B[0][-1]:
        return 0
    elif A[0][0] <= B[0][0]:
        return -1
    elif A[0][0] >= B[0][0]:
        return 1

def sort_sequences(sequences_scores):
    """
    >>> ss = [((5,6,10,11),0), ((1,2,3,4,5),0), ((2,3),0), ((13,14,15),0)]
    >>> sort_sequences(ss)
    >>> [((1,2,3,4,5),0),((2,3),0),((5,6,10,11),0),((13,14,15),0)]
    """
    #print '*'*80
    #print sequences_scores
    #print '*'*80
    return sorted(sequences_scores, cmp=sequences_compare)


# description needs to be modified
def RLCS_window(testVal, refVal, Td, rho, beta, extrTd, alpha, seqFilterTd, window, shiftPoints, st_test, st_ref, algo):
    '''
    This function runs the RLCS on test and ref by windowing the test
    by length(ref)*1.5 with a shift of one.
    '''
#    print hello
    #print(testVal, refVal, shiftPoints, st_test, st_ref)
    N = len(refVal)
    toggle = False
    if len(testVal) < len(refVal):
        toggle = True
        [testVal, refVal] = [refVal, testVal]
        [st_test, st_ref] = [st_ref, st_test]
        if shiftPoints: # this means second pass so,
            shiftPoints = [x for x in range(0,len(testVal),3)]
            
       
    # this is the part that got shifted from the below function.
    if shiftPoints: 
        shiftPoints = [temp-shiftPoints[0] for temp in shiftPoints]


    lenRef = len(refVal)
    lenTest = len(testVal)

    sequences = []
    scores = []
    costs = []
    costDs = []
    lens_test = []
    lens_ref = []
    wats = []
    wars = []
    #diags = []
    uniques_test = [] # to store unique points of matched test
    uniques_ref = [] # to store unique points of matched ref
    
    st = 0

    # window is of size 1.5 times the length of ref
    winLen = int(lenRef*window)
    ed = st + winLen
    
    # if window length is greater than length of test or
    # window is False (i.e. no windowinf) then we make window
    # to be the length of test
    if ed > lenTest or window == 0:
        ed = lenTest

    i = 3
    testValSegs = []
    stPass = []
    while(ed <= lenTest):
        # to pass to helper func
        if ed-st+1>1: stPass.append(st)
        if ed-st+1>1: testValSegs.append(testVal[st : ed])
        
        if shiftPoints:
            if i<len(shiftPoints): st = shiftPoints[i]
            else : st = shiftPoints[-1]
            ed = st + winLen
            #print '   RLCS_window: ' + str(i)
            #print st
        else:
            st = st + 1
            ed = st + winLen
        
        i += 3
    results = []
    if testValSegs:
      print 'Entering Pool...'
      pool = Pool(16)   
      args =zip(testValSegs, itl.repeat(refVal), itl.repeat(Td), itl.repeat(rho), itl.repeat(beta), itl.repeat(extrTd), itl.repeat(alpha), itl.repeat(N), itl.repeat(toggle), itl.repeat(seqFilterTd), stPass, itl.repeat(st_test), itl.repeat(st_ref), xrange(len(testValSegs)), itl.repeat(algo))
    
    #print (lenRef, lenTest)
    #print (testValSegs)
    #print args
    #a = raw_input('pause')
      results = pool.map(RLCS_window_helper, args)

      print 'Exit Pool2 ...'
      pool.close()
      print 'Exit Pool1 ...'

    #pool.terminate()
      pool.join()
      print 'Exit Pool0 ...'

      results = [tuple([rr[0] for rr in result]) for result in results if result[0]]
    
    
    [sequences, scores, costs, costDs, lens_ref, lens_test, wats, wars, uniques_test, uniques_ref] = [[],[],[],[],[],[],[],[],[],[]]
    
    #print result    
    if results:
        [sequences, scores, costs, costDs, lens_ref, lens_test, wats, wars, uniques_test, uniques_ref] = zip(*results)
   # print sequences

        
    # this is to check the invariant
    if len(sequences) != len(scores) or\
       len(scores) != len(costs) or \
       len(costs) != len(lens_test) or\
       len(lens_test) != len(lens_ref) or\
       len(lens_ref) != len(wats) or\
       len(wats) != len(wars) or\
       len(wars) != len(uniques_test) or\
       len(uniques_test) != len(uniques_ref): #or\
       #len(uniques_ref) != len(diags):
        
        print ("***********")
        print (len(sequences) ,len(scores),
               len(costs), len(lens_test),
               len(lens_ref), len(wats),
               len(wars),
               len(uniques_test), len(uniques_ref))
               #len(diags))
        
        print ("***********")
        exit("len(sequences) ,len(scores), len(costs), len(lens_test), len(lens_ref), len(wats), len(wars), len(sequences), len(scores), len(uniques_test), len(uniques_ref) are not equal\n")

    # this is a sequences tuple representing the entire sequence
    sequences_tuple_sorted = sort_sequences(zip(sequences,scores, costs,costDs,
                                                lens_test, lens_ref,
                                                wats, wars, uniques_test,
                                                uniques_ref
                                                )
                                            )

    # using set to identify a group 
    min_val, max_val = -1, -1
    
    # Each element represents a group and each group consists of some
    # sequences. Each sequence is a tuple of sequence and
    # corresponding score value.
    sequences_group = [[]]
    
    i = 0
    
#    print sequences_tuple_sorted
    for sequence_tuple in sequences_tuple_sorted:
        # get the x_indexs of the sequence in the sequence_tuple
        seq = zip(*sequence_tuple[0])[0]
        if min_val == -1 and max_val == -1:
            sequences_group[i].append(sequence_tuple)
            min_val = seq[0]
            max_val = seq[-1]

        elif seq[0] <= max_val:
            temp = []
            for seq_grp in sequences_group[i]:
                temp.append(zip(*seq_grp[0])[0])
            if not seq in temp:
                sequences_group[i].append(sequence_tuple)
            max_val = max(max_val, seq[-1])
            min_val = min(min_val, seq[0])
            
        else:
            
##            #if not sequences_group[i]:
##            print sequences_group[i]
##            a = input('\nEnter')
            
            i += 1
            sequences_group.append([])
            sequences_group[i].append(sequence_tuple)
            min_val = seq[0]
            max_val = seq[-1]

##    print i
##    print sequences_group
##    input('Enter')
    return [sequences_group]


def RLCS_window_helper(args): return RLCS_window_helper0(*args)

def RLCS_window_helper0(testValSeg, refVal, Td, rho, beta, extrTd, alpha, N, toggle, seqFilterTd, st, st_test, st_ref,myiter, algo):
    print ('Printing from iteration : ' + str(myiter))

    if algo == 'rlcs':   
      [c,cd,d,wr,wt,s] = RLCS(testValSeg, refVal, Td, rho, beta, extrTd, alpha, N, toggle)
    elif algo =='rlcsmod':
      [c,cd,d,wr,wt,s] = RLCS_mod(testValSeg, refVal, Td, rho, beta, extrTd, alpha, N, toggle)
    else :
      error('value of algo is not-valid. Correct options "rlcs" or "rlcsmod"')
           
    starts = filter2D(s, seqFilterTd, c,cd, wt, wr)
  
    [sequences_w, scores_w,costs_w,costDs_w,
    lens_test_w, lens_ref_w,
    wats_w,wars_w, uniques_test_w,
    uniques_ref_w] = get_unique_seqs(testValSeg, refVal, d, starts, rho, len(refVal), c, st + st_test, st_ref, toggle)

##        print(len(testVal[st:ed]), len(refVal))
##        for seq in sequences_w :
##            print(len(seq))
##
    sequences = sequences_w[0:1]
    scores = scores_w[0:1]
    costs = costs_w[0:1]
    costDs = costDs_w[0:1]
    lens_ref = lens_ref_w[0:1]
    lens_test = lens_test_w[0:1]
    wats = wats_w[0:1]
    wars = wars_w[0:1]
    uniques_test = uniques_test_w[0:1]
    uniques_ref = uniques_ref_w[0:1]

    return (sequences, scores, costs, costDs, lens_ref, lens_test, wats, wars, uniques_test, uniques_ref)

# need some modification w.r.t. to previous run_LCSS func (highly redundant)
def RLCS_same_raga_many_alaps(refDir, testDir, outDir, labelDir, \
                              extn, Td, rho, beta, extrTd, alpha, \
                              seqFilterTd, mode, window, shiftDir, \
                              voiced,voicedInfoRefExtn,voicedInfoTestExtn, algo):
    '''(dir,dir) -> dir

    THIS DOC NEEDS TO BE UPDATED

    For each ref in refdir find the RLCS with each of test in testdir
    and store the output in the outdir. Do not forget to include '/'
    at end of the dir names.
    
    '''
#    print 'inside same raga'
    #print refDir
    refs = [ref for ref in os.listdir(refDir) if ref.endswith(extn)]
    tests = [test for test in os.listdir(testDir) if test.endswith(extn)]
    
   
    ###############
    #print refs
    #print tests
    #a = input('pausing')
    ############### 


 
    os.makedirs(outDir)

    # for debug mode
    if mode == '--debug':
        os.makedirs(outDir[:outDir.rfind('/')] +
                    '/debug.log'+ outDir[outDir.rfind('/'):])
    #print refs
    
    for ref in refs:
        # making ref directory
        
        #print refDir, testDir, outDir,extn
        os.makedirs(outDir + '/' + ref)
        if voiced:
            VADDir = outDir + '/' + ref + '/' + 'VAD'
            os.makedirs(VADDir)
        # for debug mode
        if mode == '--debug':
            os.makedirs(outDir[:outDir.rfind('/')] +
                        '/debug.log' + outDir[outDir.rfind('/'):]
                        + '/' + ref)
        
        
        # extracting motif name from the reference file name.
        motifName = ref.split('.')[-3]
       

        with open(refDir + '/' + ref) as f:
            col1, col2, col3 = zip(*[(float(x.split()[0]),\
                                      float(x.split()[1]),\
                                      [float(xx) for xx in x.split()[2:]])\
                                      for x in f.readlines()])
            refVal = zip(col1, col3)
            ref_x_indexes = col2

        for test in tests:

            with open(testDir + '/' + test) as f:
                col1, col2, col3 = zip(*[(float(x.split()[0]),\
                                          float(x.split()[1]),\
                                          [float(xx) for xx in x.split()[2:]])\
                                         for x in f.readlines()])
                testVal = zip(col1, col3)
                x_indexes = col2
	    
            if len(testVal) <  3: continue
            
            print('*'*80) # decoration
            print('REF: ' + ref + ', ' 'TEST: ' + test + '\n')
           

		 
            
            # it will stores the indices of the samples from
            # the LabFile (first column * 100) in the test.
            # only makes sense when debug mode is on
            gt_sample_indices = []

            if mode == '--debug':
                os.makedirs(outDir[:outDir.rfind('/')] +
                            '/debug.log' + outDir[outDir.rfind('/'):]
                            + '/' + ref + '/' + test)
            
                # making the ground truth filename
                ground_truth = test[:test.rfind(extn)] + 'lab'

                # getting the ground truth of the x_indexes
                with open(labelDir + '/' + ground_truth) as f:
                    gt_x_indexes = [ (int(math.ceil(float(x.split()[0])*100)),
                                      int(math.ceil(float(x.split()[1])*100)) + int(math.ceil(float(x.split()[0])*100)))\
                                     for x in f.readlines()\
                                     if x.split()[-1] == motifName]
                    
                    
                    for gt_x_index_start, gt_x_index_end in gt_x_indexes:
                        gt_x_index_start_range = [x for x in range(gt_x_index_start - 1000,\
                                                                   gt_x_index_start + 1000)\
                                                  if x in x_indexes]
                        gt_x_index_end_range  =  [x for x in range(gt_x_index_end - 1000,\
                                                                   gt_x_index_end + 1000)\
                                                  if x in x_indexes]
                        
                        gt_sample_indices.append(
                                                 (
                                                   x_indexes.index(gt_x_index_start_range[
                                                                    argmin([abs(gt_x_index_start-tt)
                                                                            for tt in gt_x_index_start_range])]),
                                                   x_indexes.index(gt_x_index_end_range[
                                                                    argmin([abs(gt_x_index_end-tt)
                                                                            for tt in gt_x_index_end_range])])
                                                 )
                                                )
                        #print(str(gt_sample_indices[-1]) + ' ground truth motif')
                    
            
            # if shiftDir is not empty then get the shiftPoints from the
            # appropriate xinf file otherwise make shiftPoints an empty list.
            
            if shiftDir:
                with open(shiftDir + refDir[refDir.rfind('/')+1:] + '/' + test.rpartition('.wav')[0] + '.wav'+'.xinf') as f:
                    #print('inside shiftdir cond...\n')
                    
                    ###############
                    ## This part of code is shifted in the RLCS_window function...
                    ## that is making starting shift as 0
                    ##########
                    #temps = [int(float(point)) for point in f.readlines()]
                    #first = temps[0]
                    #shiftPoints = [temp-first for temp in temps]
                    shiftPoints = [int(float(point)) for point in f.readlines()]  
            else:
                shiftPoints = []

            
            #print voiced
            #a = input('ddew')
            if voiced in [2,3]:
                voicedRefExtn = '.wav.' + voicedInfoRefExtn
                voicedTestExtn = '.wav.' + voicedInfoTestExtn

#		print voicedRefExtn, voicedTestExtn
                with open(refDir + '/' + ref[:ref.rfind('.wav')] + voicedRefExtn) as vf:
                    voicedRefs = [(int(float(x.split()[0])), int(float(x.split()[1])))\
                                 for x in vf.readlines()]
                    
                with open(testDir + '/' + test[:test.rfind('.wav')] + voicedTestExtn) as vf:
                    voicedTests = [(int(float(x.split()[0])), int(float(x.split()[1])))\
                                 for x in vf.readlines()]
                    
                count_true = 0
                sequences_group = []
                vi = 1
                voicedRefLines = []
		
                #########
                #print voicedRefs
                #print voicedTests
                #a = input('pasuinh')
##                print 'num of REF_orig: '+ str(len(refs))
##                print 'num of voiced in ref1: '+ str(len(voicedRefs)) 
                #########

                
                #print 'REFV Check IN'

                voicedRefsCopy = copy.deepcopy(voicedRefs)
                for voicedRefStart, voicedRefEnd in voicedRefsCopy:
                    voicedRefStartRange = [x for x in range(voicedRefStart - 500,\
                                                            voicedRefStart + 500)\
                                           if x in ref_x_indexes]
                    voicedRefEndRange   = [x for x in range(voicedRefEnd - 500,\
                                                            voicedRefEnd + 500)\
                                           if x in ref_x_indexes]
                     
                    if not voicedRefStartRange or not voicedRefEndRange:
                      voicedRefs.remove((voicedRefStart, voicedRefEnd))
                      continue
                            
                    voicedRefLines.append(
                                               (
                                                   ref_x_indexes.index(voicedRefStartRange[
                                                                            argmin([abs(voicedRefStart-tt)
                                                                            for tt in voicedRefStartRange])]),
                                                   ref_x_indexes.index(voicedRefEndRange[
                                                                            argmin([abs(voicedRefEnd-tt)
                                                                            for tt in voicedRefEndRange])])
                                               )
                                            )

                #print 'REFV Check OUT'

                #print 'testV Check IN'
                #print voicedTests
                voicedTestLines = []
                for voicedTestStart, voicedTestEnd in voicedTests:
                    voicedTestStartRange = [x for x in range(voicedTestStart - 500,\
                                                            voicedTestStart + 500)\
                                           if x in x_indexes]
                    voicedTestEndRange   = [x for x in range(voicedTestEnd - 500,\
                                                            voicedTestEnd + 500)\
                                           if x in x_indexes]

                    if not voicedTestStartRange or not voicedTestEndRange:
                      voicedTests.remove((voicedTestStart, voicedTestEnd))
                      continue

                   # print voicedTestStart, voicedTestEnd, x_indexes
                    voicedTestLines.append(
                                               (
                                                   x_indexes.index(voicedTestStartRange[
                                                                            argmin([abs(voicedTestStart-tt)
                                                                            for tt in voicedTestStartRange])]),
                                                   x_indexes.index(voicedTestEndRange[
                                                                            argmin([abs(voicedTestEnd-tt)
                                                                            for tt in voicedTestEndRange])])
                                               )
                                            )
                    
                refCount = 1
                for voicedRef, voicedRefLine in zip(voicedRefs, voicedRefLines):
                    tempOutDirName = outDir + '/' + ref + '/' + ref + '.vp' + str(vi)

                    if not os.path.exists(tempOutDirName):
                        os.makedirs(tempOutDirName)
                    
                    voicedRefVal = [ref_val for ref_val, r_x_index in zip(refVal, ref_x_indexes)\
                                     if r_x_index in range(voicedRef[0], voicedRef[1] + 1)]

                    ##############################
                    #########ZERO-MEAN############
                    ##############################
                    # first do unzip to get the feat vec
                   # [col1, featVects] = zip(*voicedRefVal)
                   # a = np.array(featVects, dtype = float)
                   # featVects = (a - a.mean(axis=0)).tolist()
                   # voicedRefVal = zip(col1, featVects)
                    ##############################
 

                    ##############
#                    print 'len of voice part: ' + str(len(voicedRefVal))
##                    input()
                    ##############
                    widgets1 = ['Voiced Motif ' + str(refCount) + ': ' , Percentage(), ' ', Bar(marker='=',left='[',right=']'),
                               ' ', ETA()]  
                    refCount += 1
                   
                    bar = ProgressBar(maxval=len(voicedTests), widgets=widgets1)
 
                    f =  open(tempOutDirName + '/' + test + '_result','w'); f.close()
                    sequences_group0 = []
		    perc = 1 # to calc percentage completioni
                    bar.update(0)
                    for voicedTest, voicedTestLine in zip(voicedTests, voicedTestLines):

			#basically shiftPoints contain the infPoints for that reagion
			shiftPoints0 = [xs for xs in shiftPoints if xs in range(voicedTest[0], voicedTest[1] + 1) ]

		        #getting the reagion and forcing it to start from an infPoint (staring one)
                        if shiftPoints0:
                           voicedTestVal = [test_val for test_val, x_index in zip(testVal, x_indexes)\
                                           if x_index in range(voicedTest[0], voicedTest[1] + 1) and x_index >= shiftPoints0[0]]

                        else:
                           voicedTestVal = [test_val for test_val, x_index in zip(testVal, x_indexes)\
                                           if x_index in range(voicedTest[0], voicedTest[1] + 1)]

                        
                        ##############################
                        #########ZERO-MEAN############
                        ##############################
                        # first do unzip to get the feat vec
                        #[col1, featVects] = zip(*voicedTestVal)
                        #a = np.array(featVects, dtype = float)
                        #featVects = (a - a.mean(axis=0)).tolist()
                        #voicedTestVal = zip(col1, featVects)
                        ##############################
 
 
                        #print 'going inside RLCS window' 
                        [sequences_group00] = RLCS_window(voicedTestVal, voicedRefVal, Td, rho,
                                                          beta, extrTd, alpha,
                                                          seqFilterTd, window, shiftPoints0,
                                                          voicedTestLine[0], voicedRefLine[0], algo)
                       
                        print 'bar update start...' 
                        if perc+1 <= len(voicedTests): bar.update(perc+1)
                        print 'bar update end...'
                        #print 'VAD seg ' str(perc) + ' : ' +  str(perc/len()*100) + '% completed'
                        perc += 1
                        
                        print 'write start...'
                        if sequences_group00[0]:
                           count_true += write_to_file(sequences_group00, testDir + '/'+ test,
                                           refDir + '/' + ref,
                                           tempOutDirName + '/' + test + '_result',
                                           gt_sample_indices, motifName, mode)
                        #print 'coming out of RLCS window' 
                        print 'write finish...'

                        if sequences_group00[0]:
                            sequences_group0 += sequences_group00
                    
                    bar.finish()    
#                    count_true += write_to_file(sequences_group0, testDir + '/'+ test,
#                                           refDir + '/' + ref,
#                                           tempOutDirName + '/' + test + '_result',
#                                           gt_sample_indices, motifName, mode)
                    if sequences_group0:
                        sequences_group += sequences_group0

                    [fs, wavefile] = sciwav.read(refDir + '/' + ref[:ref.rfind('.wav')] + '.wav')
                    sciwav.write(VADDir + '/' + ref[:ref.rfind('.wav')] + '.vp' + str(vi)+ '.wav' , fs,
                                 wavefile[int(voicedRef[0]*fs/100) : int(voicedRef[1]*fs/100)])
                    
                    vi += 1
                
            
            else:
                [sequences_group] = RLCS_window(testVal, refVal, Td, rho,\
                                                beta, extrTd, alpha,\
                                                seqFilterTd, window, shiftPoints,\
                                                0, 0, algo)
            
                count_true = write_to_file(sequences_group, testDir + '/'+ test,
                                           refDir + '/' + ref,
                                           outDir + '/' + ref + '/' + test + '_result',
                                           gt_sample_indices, motifName, mode)
            
            #print('\nThese are the total sequences found:')
            #for sequence,score in zip(sequences,scores):
            #    print(zip(*sequence)[0],score)
            #g = 0
            #for seq_grp in sequences_group:
            #    if seq_grp:
            #        print ('group : ', g+1)
            #        g += 1
            #        for seq in seq_grp:
            #            print (zip(*seq[0])[0],seq[1])
            #        print('')
            
            if mode == '--debug':    
                print('\nChecking for true positives in the sequences found...')    

            #print ('\nTotal groups found: ' + str(g))
            
            if mode == '--debug':
                print ('Total number of ground truth motifs: ' + str(len(gt_sample_indices)))
                print ('Total number of identified ground truth motifs: ' + str(count_true))
                print ('\n')
                if (count_true > len(gt_sample_indices)):
                    print('ERROR: true positives are more than the ground truth motifs.\n')


def RLCS_many_ragas(testsDir, refsDir, outsDir, labelsDir, extn, Td,\
                    rho, beta, extrTd, alpha, seqFilterTd, mode, window, shiftDir,
                    voiced,voicedInfoRefExtn,voicedInfoTestExtn, algo):
    '''
    Precondition: All the directories (raags) in refsDir should also
    be present in testsDir.

    This function runs the "run_RLCS" function for all the Raags in
    testsDir and refsDir and stores the result in outsDir.


    NOTE: Do not forget to include '/' at end of the dir names.
    '''

    # for each refDir(raaga) in refsDir run the run_RLCS function for
    # the correspoding raaga in testsDir.


    if not os.path.exists(outsDir):
        os.makedirs(outsDir)
        if mode == '--debug':
            os.makedirs(outsDir + 'debug.log/')
    else:
        print("\nDeleting already existing " + outsDir + "\n")
        os.system("rm -rf " + outsDir)
        print("New one created\n")
        os.makedirs(outsDir)
        if mode == '--debug':
            os.makedirs(outsDir + 'debug.log/')
            
    for refDir in os.listdir(refsDir):
        print("\nRunning RLCS for raaga " + refDir + "\n")

        RLCS_same_raga_many_alaps(refsDir + refDir,\
                                   # read the precondition above
                                   testsDir + refDir,\
                                   outsDir + refDir,\
                                   labelsDir + refDir,\
                                   extn, Td, rho, beta, extrTd,\
                                   alpha, seqFilterTd, mode, window,
                                  shiftDir, voiced, voicedInfoRefExtn,
                                  voicedInfoTestExtn, algo)
        
        print("\nFinished running RLCS for raaga " + refDir + "\n\n")
