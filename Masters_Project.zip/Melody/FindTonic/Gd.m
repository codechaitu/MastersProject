function R = Gd(a,scaleFactor,gamma,hp,alpha) % Have implemented as is from the front-end-dsp. Not optimized for matlab
nfft=4096;
sigCopy=[];
%scaleFactor=1;
histArray=a';
[n numBins]=size(histArray);
sigCopy(1) = exp(gamma*log(histArray(1)+1));
sigCopy1(1) = exp(gamma*log(histArray(1)+1));
   for k = 1:numBins 
       sigCopy1(k)=exp(gamma*log(histArray(k)+1));
    sigCopy(k) = exp(gamma*log(histArray(k)+1));
    sigCopy(nfft-k+1) = sigCopy(k);
   end
  sigCopy=sigCopy/max(sigCopy);
  sigCopy1=sigCopy1/max(sigCopy1);
  rMin=min(sigCopy1);
  
   for k = numBins + 1 : nfft-numBins+1
    sigCopy(k) = rMin;
   end
   sigCopy1=sigCopy;
   
  winlen = ceil(numBins/scaleFactor);
  winlen = winlen;
  sigCep=real(ifft(sigCopy,nfft));
  R.sigCep=sigCep;
  ay=imag(ifft(sigCopy,nfft));
  v=hamming(2*winlen);
  v1=hannpoisson(2*winlen,alpha);
  for k = 1:winlen
      if hp ==1
        sigCopy(k) = sigCep(k).*v(winlen+k);
      else
        sigCopy(k) = sigCep(k).*v1(winlen+k);
      end
  %  sigCopy(k) = v(winlen+k);
  end
  for k = winlen:nfft
      sigCopy(k) = 0;
  end
  R.sigCopy=sigCopy;
  ax=real(fft(sigCopy,nfft));
  ay=imag(fft(sigCopy,nfft));
  amag=abs(fft(sigCopy,nfft));
  phase=angle(fft(sigCopy,nfft));
 % phase=unwrap(phase);
  nfBy2 = nfft/2;
R.amag=amag;
P.ph=phase;
  for k = 1 :  winlen-2
    smthHistArray(k) = phase(k+1) - phase(k+2);
  end
  smthHistArray(winlen-1) = smthHistArray(winlen-2);
  smthHistArray(winlen) = smthHistArray(winlen-1);
  R.phase=phase;
  R.GdHistogram=smthHistArray/max(smthHistArray);
 % R.GdHistogram(R.GdHistogram<0)=0;
  R.GdHistogram=R.GdHistogram';
