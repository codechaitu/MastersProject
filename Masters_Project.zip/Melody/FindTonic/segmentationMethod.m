function R =  segmentationMethod(f0,mf,hopSize)
split = 6000*hopSize/0.01;
size(f0);
[r s] = size(f0);
freq_split = buffer(f0,split); % segmenting data
[m n] = size(freq_split);
freq = [1:600];
[o p] = size(freq);
for i =  1 : n  % computing GD histogram for each segment
    freq_hist(:,i) = hist(freq_split(:,i),freq);
    S = Gd(freq_hist(:,i),1,1,1,0); % GD processing - requires tuning 
    gd_hist(:,i) = S.GdHistogram;
    clear S;
    gd_hist(:,i) = gd_hist(:,i)/max(gd_hist(:,i));
    freq_hist(:,i) = freq_hist(:,i)/max(freq_hist(:,i));
end
R.freq_hist = freq_hist;
gd_histpos = gd_hist;
gd_histpos(gd_histpos < 0) = 0;  % cleaning up the GD bit
prod1 = ones(p,1);
%prod2 = ones(p,1);

for i =  1:n
    prod1 = prod1.*((gd_histpos(:,i))+1); % Multiplying histograms bin wise
 %   prod2 = prod1 + ((gd_histpos(:,i))+1);
end
 
data(:,1) = prod1;
%data(:,2) = prod2;
if mf ==  '1'  % assigning peak picking ranges depending on metadata
    rangeMin = 110;
    rangeMax = 170;
    
elseif mf ==  '2'
    rangeMin = 140;
    rangeMax = 240;
elseif mf ==  '3'
    rangeMin = 120;
    rangeMax = 220;
elseif mf ==  '5';
    rangeMin = 60;
    rangeMax = 420;
elseif mf ==  '4'
        rangeMin = 100;
       rangeMax = 240;
elseif mf ==  '6'
        rangeMin = 50;
        rangeMax = 90;
elseif mf ==  '7'
       rangeMin = 70;
       rangeMax = 120;
   elseif mf ==  '8'
        rangeMin = 60;
        rangeMax = 110;
   elseif mf ==  '9'
        rangeMin =  50;
        rangeMax =  230;
    else mf ==  '10'
        rangeMin =  50;
        rangeMax =  120;

end

for i =  1 : 1
    [m ind] = max(data((rangeMin:rangeMax),i));
    peak(i) = rangeMin + ind;
end
maxPeak = freq(peak); 
R.maxPeak = maxPeak;
