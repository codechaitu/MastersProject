function reqTonic = getTonicGD(fileName,varargin)
    %%%%%%%%%%%%%%%%%%%%%%
    % fileName = full path to pitch file of the audio for which tonic has to be determined
    % file format - pitch should be first column of the file, each row representing the pitch of a paricular frame
    % metadata = 1 male; 2 female; 3 Instrumental; 4 - not known; Default = 4;
    % hopSize = frame Shift when extracting pitch in seconds - required for segmented histogram method. Default value 0.01s

    % Example ----> R=getTonicGD('8b065998-c988-4c70-bf33-cb3428ce2d25_0-180.mp3.freq', 'metadata', 1, 'hopSize' , 0.01)
    [metadata, hopSize] = parse_opt(varargin, 'metadata', 1, 'hopSize', 0.02);
    mf = num2str(metadata);
    f0 = load(fileName);
    freq.f0 = f0(:,2);
    freq.f0 = freq.f0(freq.f0 < 601);
    M1 = segmentationMethod(freq.f0,mf,hopSize);  %%% Method 1 - segmented histogram 
    bins = [1:600];
    freq.Histogram1 = hist(freq.f0,bins);  % computing histogram
    freq.Histogram = freq.Histogram1'/sum(freq.Histogram1); % Normalizing histogram
    R = Gd(freq.Histogram1',1,1,1,1); % Group delay processing  - GD is the function
    freq.GdHistogram = R.GdHistogram/sum(R.GdHistogram);  % Normalizing the GD histogram (optional)
    disp('Before template matching');
    M2 = templateMatchingMethod(freq.GdHistogram,bins,mf,freq.Histogram1)  % Method 2 - Template matching
    R = horzcat(M1.maxPeak, M2.tonic);
    reqTonic = M2.tonic;
    %reqTonic = M1.maxPeak;
end


