
function[] =prepareOutputTonic()
    %getting tonic values
    genres = {'Classical','Folk','Western'};

    for i = 1 : length(genres)
        genre = char(genres(i));
        reqDir = strcat('./Genre/Pitch/',genre,'/');
        tonicValues = load(strcat(reqDir,'GDTonicValues.mat'));
        tonicValues = tonicValues.GDTonicValues;
        
        %getting songNames
        songNames = cell(length(tonicValues),1);
            fid = fopen(strcat(reqDir,'songNames.txt'));
            count = 1;
            tline = fgetl(fid);
            while ischar(tline)
                songNames{count,1} = tline;
                tline = fgetl(fid);
                count = count + 1;
            end
             fclose(fid);
        

        dir = strcat('./Genre/Tonic/',genre,'/');;
        for i = 1:length(tonicValues)
            fileName = songNames{i};
            tonic = tonicValues(i);
            file = strcat(dir,fileName,'.txt');
            fid = fopen(file,'wt');
            fprintf(fid,'%s\n%s%s','#!/bin/bash','TONIC=',num2str(tonic));
            fclose(fid);    
        
        end
     end
end
