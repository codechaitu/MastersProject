% read all the pitch values
genres = {'Classical','Folk','Western'};

for i = 1 : length(genres)
genre = char(genres(i));
songLocation = strcat('/others/shiva/Tamil_Music/Genre/',genre);
files = dir(strcat('./Genre/Pitch/',genre,'/Output_Pitch/','*.pitch'));

% writing all tonics to files
count = 1;
fid = fopen(strcat('./Genre/Pitch/',genre,'/TonicValues.txt'),'wt');
fid1 = fopen(strcat('./Genre/Pitch/',genre,'/songNames.txt'),'wt');
fid2 = fopen(strcat(songLocation,'/songLocations.txt'),'wt');
for file = files'
     freq = (strcat('./Genre/Pitch/',genre,'/Output_Pitch/',file.name));
     temp = file.name;temp = strrep(temp,'.pitch','');songName = temp;
     tonic = getTonicGD(freq, 'metadata', 1, 'hopSize' , 0.02);
     GDTonicValues(count) = tonic;
     count = count + 1;
     fprintf(fid,'%-30s %s Hz\n',songName,num2str(tonic));
     fprintf(fid1,'%s\n',songName);
     fprintf(fid2,'%-30s %s\n',strcat(songLocation,'/',songName,'.wav'),num2str(tonic));
end
save(strcat('./Genre/Pitch/',genre,'/GDTonicValues.mat'),'GDTonicValues');
fclose(fid);
fclose(fid1);


end
