function R = templateMatchingMethod(histogram,freq,mf,histogramN)  %%% Too many variables needs cleaning!!!
differ = diff(histogram); %to pick peaks, first diff
start = freq(1);
[m n] = size(histogram);
Zc = zeros(2*m,1);
peaks = zeros(m,1);
hop = freq(2)-freq(1);
posZc = 1;
%mf = 0;
if mf == '1'
    rangeBeg = 100;
    rangeEnd = 180;
    
  elseif mf == '2'
    rangeBeg = 140;
    rangeEnd = 240;
  elseif mf == '3'
    rangeBeg = 120;
    rangeEnd = 220;
  elseif mf == '5';
    rangeBeg = 60;
    rangeEnd = 420;
  elseif mf == '4'
        rangeBeg = 100;
       rangeEnd = 240;
   elseif mf == '6'
        rangeBeg = 50;
        rangeEnd = 90;
   elseif mf == '7'
       rangeBeg = 70;
       rangeEnd = 120;
   elseif mf == '8'
        rangeBeg = 60;
        rangeEnd = 110;
   elseif mf == '9'
        rangeBeg = 50;
        rangeEnd = 230;
    else mf == '10'
        rangeBeg = 50;
        rangeEnd = 120;

end
err = 5; % Delat i.e template width - 5 bins is default
histogram = histogram./max(histogram); %Normalizing
signVal = sign(differ);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Peak Picking%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 2 : m-1
   if  ((((signVal(i-1) == 1) && (signVal(i) == -1)) || ((signVal(i-1) == 1) && (signVal(i) == -1)) ) && (histogram(i) > 0))
    Zc(i) = 1;
    peaks(i) = histogram(i);
   end
end
sum(peaks)
sumPeak = zeros(m,1);
sumPeak1 = zeros(m,1);
sumPeak_weigh = zeros(m,1);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%Template Matching%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           

%   S      R1     R2      G1      G2    M1     M2     P      D1     D2    N1     N2     S
% 0.5000 0.5335 0.5625 0.6000  0.6250 0.6665 0.7085 0.7500 0.8000 0.8335 0.9000 0.9375  1
%          R1     R2      G1      G2    M1     M2     P      D1     D2    N1     N2     S 
%         1.067 1.125  1.200   1.250  1.333  1.417  1.500  1.600  1.667  1.800  1.875   2 
%          R1     R2      G1      G2    M1     M2     P      D1     D2    N1     N2     S  
%         2.134 2.2500 2.4000  2.5000 2.6660 2.8340 3.0    3.2000 3.3340 3.60   3.750   4

ragaTemp = [0.75 1 1.5 2 3]; % P S P S Ptemplate - can be tuned to improve performance - here i am changing the template
%weights = [0.5 0.5 1 0.5 1 1];
for i = round((rangeBeg - start)/hop): round((rangeEnd - start)/hop)
    if (peaks(i) > 0)
        disp('Entered');
        Sa = freq(i);
        [r s] = size(ragaTemp);
        ragaTemplate = round(i+ ((Sa*(ragaTemp) - Sa)/hop));
        if (2*i < 600)
   %     areaPeak(i) = sum(histogramN(i:2*i));
        end
        for j = 1:s
            disp('opened');
                if ((ragaTemplate(j) > err+1 && ragaTemplate(j) < m-err-1))
                    sumPeak(i) = sumPeak(i)+ sum(peaks(ragaTemplate(j) - err : ragaTemplate(j) + err)); %Plain peak matching
                
                    sumPeak1(i) = sumPeak1(i)+ (histogram(i))*sum(peaks(ragaTemplate(j) - err : ragaTemplate(j) + err)); % Weighing by the value of peaks
                end
        end
       sumPeak1(i) = 1*sumPeak1(i) +  0*sumPeak(i); % To experiment with various templates
    end
 end
R.Zc = Zc;
R.peaks = peaks;
R.sumPeak = sumPeak;
R.sumPeak1 = sumPeak1;

%%%%%%%%%%%%%%%%%%%%%%Method 1 Weighing%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[o p] = max(R.sumPeak1);
Tonic_method(1) = start + p*hop;
R.tonic = Tonic_method;
%[ba R.area] = max(areaPeak);
