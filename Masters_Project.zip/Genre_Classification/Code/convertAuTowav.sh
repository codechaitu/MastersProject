
folder="folders.txt"
numProc=5;
less $folder | parallel -v -j$numProc cd {1} && ls | grep -v au$ >> {1}.txt
