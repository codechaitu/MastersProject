clear all
genreList = {'Classical';'Folk';'Western'};
feature = 'Chroma';
ending = 'chroma';
location = strcat('./GenreFeatures/',feature,'/');  %change location when run on other server
totalSongs = 55; % in each genre
numOfTrain = 40;
%numOfTest = totalSongs - numOfTrain;

trainMatrix = [];
trainLabels = [];
testMatrix = [];
testLabels = [];
testCounts=[]; % counting total number of rows each test song has taken
trainPrevious = 0;
testPrevious = 0;
% Train & Test dataset
for i = 1 : length(genreList)
   genre =  char(genreList(i));
   reqDir = strcat(location,genre,'/');
   files = dir(strcat(reqDir,'*.',ending));
   count = 1;
   for file = files'
       temp = load(strcat(reqDir,file.name));
       if(count<=numOfTrain)
           trainMatrix = [trainMatrix;temp];
       else
           [p,q] = size(temp);
           testCounts = [testCounts;p];
           testLabels = [testLabels;i];
           testMatrix = [testMatrix;temp];
       end
       count = count + 1;
       
   end
    [r1,c1] = size(trainMatrix);
   trainCount  = r1 - trainPrevious;
   trainLabels = [trainLabels;ones(trainCount,1)*i];
   trainPrevious = r1;
   
%    %for test
%    [r2,c2] = size(testMatrix);
%    testCount  = r2 - testPrevious;
%    testLabels = [testLabels;ones(testCount,1)*i];
%    testPrevious = r2;
    
end


options1            = statset('Display', 'final');
k1                  = 2;
gm1                 = fitgmdist(X1, k1, 'Options', options1);

options1            = statset('Display', 'final');
k1                  = 2;
gm1                 = fitgmdist(X1, k1, 'Options', options1);

options1            = statset('Display', 'final');
k1                  = 2;
gm1                 = fitgmdist(X1, k1, 'Options', options1);


p = [pdf(gm1,Xt), pdf(gm2,Xt), pdf(gm3,Xt)];    % P(x|model_i)
[,cIdx] = max(p,[],2);  
