% code to get the components of audio clips
location = '../Genre_Classification/';

%genres = {'Classical','Folk','Western'};
genres = {'Classical'};
numOfGenres = length(genres);
for i = 1 : numOfGenres
   genre = char(genres{i} );
   wav_songs = strcat(location,genre,'/fullsec/wav/Wav_Mono/');
   wav_labels = strcat(location,genre,'/fullsec/wav/Wav_Mono_Labels/');
   wav_vocal = strcat(location,genre,'/fullsec/wav/Wav_Mono_Vocal/');
   if~exist(wav_labels,'dir') mkdir(wav_labels); end
   if~exist(wav_vocal,'dir') mkdir(wav_labels); end
   
   % loop for all songs in wav_songs folder
   files = dir(strcat(wav_songs,'*.wav'));
   for file = files'
       filename = file.name; % for each song, crop the song according to the given timings in wav_labels
       [song,fs]=audioread(strcat(wav_songs,filename));
       filenameWithoutExt = strrep(filename,'.wav','');
       %read the labels file
       labelsFile = importdata(strcat(wav_labels,filenameWithoutExt,'.txt'));
       
       [labelsRow,labelsCol] = size(labelsFile);
       for j = 1 : labelsRow
          startTime = labelsFile(j,1);
          endTime = labelsFile(j,2);
          startFrame = fs*startTime;
          endFrame = fs*endTime;
          reqSong = song(startFrame:endFrame,1);
          audiowrite(strcat(wav_vocal,filenameWithoutExt,'_',int2str(j),'.wav'),reqSong,fs);
       end
       
   end
    
end   

