from pydub import AudioSegment
import os,sys

try:
#    filename = sys.argv[1]
    directory = sys.argv[1]
    
except:
#    print "usage:", sys.argv[0], "<input-dir>", "<output-dir>"
#    print "usage:", sys.argv[0], "<input-audiofile>", "<output_directory>"
#  python getPitch.py WAV_Songs_Mono wav pitch Output_Pitch
     print "usage:", sys.argv[0], "<directory namer> ---- example -> python cut_mp3.py Folk>"
     sys.exit()

time='40sec'
duration = 40
extn='mp3'
files_path = '/home/chaitu/Music/Genre Classification/'+directory+'/'
extract_path = '/home/chaitu/Music/Genre Classification/'+directory+'/'+time+'/'
if not os.path.exists(extract_path):
    os.makedirs(extract_path)
    
startMin = 0
startSec = 0

endMin = 0
endSec = duration

# Time to miliseconds
startTime = startMin*60*1000+startSec*1000
endTime = endMin*60*1000+endSec*1000

#file_name = 'Eduta Neeve'
count = 0
#for root, dirnames, filenames in os.walk(files_path):
        #print "root is : " + root  
#for file_name in filenames:
for file_name in os.listdir(files_path) :
      if file_name.endswith(extn) and count<55 :
          #infile = os.path.join(root, filename);
          #outfile = os.path.join(root, outdir,filename[:filename.rfind("." + extn)] + "."+outext)
          # Opening file and extracting segment
          print count
          count = count + 1
          file_name = file_name.replace(".mp3","")
          
          
          song = AudioSegment.from_mp3( files_path+file_name+".mp3" )
          extract = song[startTime:endTime]

            # Saving
          extract.export( extract_path+file_name+'.mp3', format="mp3")
          






