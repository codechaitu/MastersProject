1) After downloading songs; run python cut_mp3.py
2) convert to wav format; python mp3towav.py Folk 40
3) Finally convert wav to mono;  find . -type f -name "*.wav" | parallel sox {} ./Wav_Mono/{} remix -

