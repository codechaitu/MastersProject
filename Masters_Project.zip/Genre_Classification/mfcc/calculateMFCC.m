function[]= calculateMFCC()

%--------------------------parameter setting---------------------------
genreList = {'Classical';'Folk';'Western'};
mfccCompleteMatrix=[];
Tw = 25;           % analysis frame duration (ms)
Ts = 10;           % analysis frame shift (ms)
alpha = 0.97;      % preemphasis coefficient
R = [ 300 3700 ];  % frequency range to consider
M = 20;            % number of filterbank channels 
C = 13;            % number of cepstral coefficients
L = 22;            % cepstral sine lifter parameter

% hamming window (see Eq. (5.2) on p.73 of [1])
hamming = @(N)(0.54-0.46*cos(2*pi*[0:N-1].'/(N-1)));

for i = 1 : length(genreList)
     genre = char(genreList(i));
    inputDir = strcat('/home/chaitu/Music/Genre Classification/',genre,'/40sec/wav/Wav_Mono/');
    directory = strcat(inputDir,'*.wav');
    mfccDir = strcat('/home/chaitu/Music/Genre Classification/',genre,'/40sec/wav/MFCC/');
    fbeDir = strcat('/home/chaitu/Music/Genre Classification/',genre,'/40sec/wav/FBE/');
    %if ~exist(mfccDir,'dir') mkdir(mfccDir); end
    %if ~exist(fbeDir,'dir') mkdir(fbeDir); end
    files = dir(directory);
        for file = files'
            name = file.name;
            [songSample,Fs] = audioread(strcat(inputDir,name));
            [mfccVal,fbe] = mfcc( songSample, Fs, Tw, Ts, alpha, hamming, R, M, C, L );
            %name = strrep(name,'.wav','');
            %save(strcat(mfccDir,name,'.mat'),'mfccVal');
            %save(strcat(fbeDir,name,'.mat'),'fbe');
           mfccCompleteMatrix = [mfccCompleteMatrix;mfccVal'];
        end
end
    
a = 10;

end