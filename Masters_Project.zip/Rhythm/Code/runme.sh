
list="genreList.txt";
numProc=5;
less $list | parallel -v -j$numProc python rp_extract_batch.py -a  ../GenreDatasets/Tamil/Dataset/{1}/   ./Features/{1}/


python rp_extract_batch.py -a  ../GenreDatasets/Tamil/Dataset/Classical/   ./Features/Classical/
python rp_extract_batch.py -a  ../GenreDatasets/Tamil/Dataset/Folk/   ./Features/folk/folkFeatures
python rp_extract_batch.py -a  ../GenreDatasets/Tamil/Dataset/Western/   ./Features/Western/
